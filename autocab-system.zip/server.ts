import express from 'express';
import path from 'path';
import fs from 'fs';
import cors from 'cors';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import { createServer as createViteServer } from 'vite';
import { users, userPasswords, drivers, cabs, bookings, getSystemStats } from './src/data/dbStore.js';
import { User, Driver, Cab, Booking } from './src/types.js';

const JWT_SECRET = 'autocab-super-secret-jwt-key-for-development';

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(cors());
  app.use(express.json());

  // Middleware to extract logged-in user from Bearer Token
  const authenticateToken = (req: any, res: any, next: any) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (!token) {
      req.user = null;
      return next();
    }

    jwt.verify(token, JWT_SECRET, (err: any, decoded: any) => {
      if (err) {
        req.user = null;
      } else {
        req.user = decoded;
      }
      next();
    });
  };

  app.use(authenticateToken);

  // --- RESTful API Routes ---

  // Health check
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', service: 'AutoCab Full-Stack API', timestamp: new Date().toISOString() });
  });

  // Auth: Register
  app.post('/api/auth/register', (req, res) => {
    const { name, email, phone, password, role } = req.body;

    if (!name || !email || !password) {
      return res.status(400).json({ detail: 'Name, email, and password are required.' });
    }

    const existingUser = users.find(u => u.email.toLowerCase() === email.toLowerCase());
    if (existingUser) {
      return res.status(400).json({ detail: 'Email address is already registered.' });
    }

    const newUser: User = {
      id: users.length ? Math.max(...users.map(u => u.id)) + 1 : 1,
      name,
      email,
      phone: phone || '+1-555-0000',
      role: role || 'user',
      createdAt: new Date().toISOString()
    };

    users.push(newUser);
    userPasswords[email] = password;

    const token = jwt.sign({ id: newUser.id, email: newUser.email, role: newUser.role, name: newUser.name }, JWT_SECRET, { expiresIn: '24h' });

    res.status(201).json({
      access_token: token,
      token_type: 'bearer',
      user: newUser
    });
  });

  // Auth: Login
  app.post('/api/auth/login', (req, res) => {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ detail: 'Email and password required.' });
    }

    const user = users.find(u => u.email.toLowerCase() === email.toLowerCase());
    if (!user) {
      return res.status(401).json({ detail: 'Invalid email or password.' });
    }

    const validPassword = userPasswords[user.email] === password || bcrypt.compareSync(password, userPasswords[user.email] || '');
    if (!validPassword) {
      return res.status(401).json({ detail: 'Invalid email or password.' });
    }

    const token = jwt.sign({ id: user.id, email: user.email, role: user.role, name: user.name }, JWT_SECRET, { expiresIn: '24h' });

    res.json({
      access_token: token,
      token_type: 'bearer',
      user
    });
  });

  // Auth: Get Profile
  app.get('/api/auth/me', (req: any, res) => {
    if (!req.user) {
      return res.status(401).json({ detail: 'Not authenticated.' });
    }
    const user = users.find(u => u.id === req.user.id);
    if (!user) {
      return res.status(404).json({ detail: 'User not found.' });
    }
    res.json(user);
  });

  // Users CRUD
  app.get('/api/users', (req, res) => {
    res.json(users);
  });

  app.delete('/api/users/:id', (req, res) => {
    const id = parseInt(req.params.id);
    const index = users.findIndex(u => u.id === id);
    if (index !== -1) {
      users.splice(index, 1);
      return res.json({ message: 'User deleted successfully' });
    }
    res.status(404).json({ detail: 'User not found' });
  });

  // Drivers CRUD
  app.get('/api/drivers', (req, res) => {
    res.json(drivers);
  });

  app.post('/api/drivers', (req, res) => {
    const { name, phone, licenseNumber, status } = req.body;
    if (!name || !licenseNumber) {
      return res.status(400).json({ detail: 'Name and license number are required.' });
    }

    const newDriver: Driver = {
      id: drivers.length ? Math.max(...drivers.map(d => d.id)) + 1 : 1,
      name,
      phone: phone || '+1-555-0100',
      licenseNumber,
      status: status || 'Available',
      rating: 5.0,
      totalRides: 0
    };

    drivers.push(newDriver);
    res.status(201).json(newDriver);
  });

  app.put('/api/drivers/:id/status', (req, res) => {
    const id = parseInt(req.params.id);
    const { status } = req.body;
    const driver = drivers.find(d => d.id === id);
    if (driver) {
      driver.status = status;
      return res.json(driver);
    }
    res.status(404).json({ detail: 'Driver not found' });
  });

  // Cabs CRUD
  app.get('/api/cabs', (req, res) => {
    const cabsWithDriver = cabs.map(c => {
      const driver = drivers.find(d => d.id === c.driverId);
      return { ...c, driverName: driver ? driver.name : 'Unassigned' };
    });
    res.json(cabsWithDriver);
  });

  app.get('/api/cabs/available', (req, res) => {
    const { cab_type } = req.query;
    let available = cabs.filter(c => c.availability === 'Available');
    if (cab_type && cab_type !== 'All') {
      available = available.filter(c => c.cabType === cab_type);
    }
    const cabsWithDriver = available.map(c => {
      const driver = drivers.find(d => d.id === c.driverId);
      return { ...c, driverName: driver ? driver.name : 'Driver Assigned' };
    });
    res.json(cabsWithDriver);
  });

  app.post('/api/cabs', (req, res) => {
    const { cabNumber, cabType, driverId, fareRatePerKm } = req.body;
    if (!cabNumber || !cabType) {
      return res.status(400).json({ detail: 'Cab number and cab type are required.' });
    }

    const newCab: Cab = {
      id: cabs.length ? Math.max(...cabs.map(c => c.id)) + 1 : 1,
      cabNumber,
      cabType,
      driverId: driverId ? parseInt(driverId) : null,
      availability: 'Available',
      fareRatePerKm: fareRatePerKm ? parseFloat(fareRatePerKm) : 3.00
    };

    cabs.push(newCab);
    res.status(201).json(newCab);
  });

  app.put('/api/cabs/:id/availability', (req, res) => {
    const id = parseInt(req.params.id);
    const { availability } = req.body;
    const cab = cabs.find(c => c.id === id);
    if (cab) {
      cab.availability = availability;
      return res.json(cab);
    }
    res.status(404).json({ detail: 'Cab not found' });
  });

  // Bookings CRUD
  app.get('/api/bookings/all', (req, res) => {
    res.json(bookings);
  });

  app.get('/api/bookings/my', (req: any, res) => {
    const userId = req.user ? req.user.id : 4; // default demo user Emily Chen if token not provided
    const userBookings = bookings.filter(b => b.userId === userId);
    res.json(userBookings);
  });

  app.post('/api/bookings', (req: any, res) => {
    const { cab_id, pickup_location, destination, fare, distanceKm } = req.body;

    if (!cab_id || !pickup_location || !destination) {
      return res.status(400).json({ detail: 'Cab ID, pickup, and destination are required.' });
    }

    const cab = cabs.find(c => c.id === parseInt(cab_id));
    if (!cab) {
      return res.status(404).json({ detail: 'Selected cab not found.' });
    }

    const driver = drivers.find(d => d.id === cab.driverId);
    const userId = req.user ? req.user.id : 4;
    const currentUser = users.find(u => u.id === userId) || users[3];

    const computedFare = fare ? parseFloat(fare) : 250.00;
    const dist = distanceKm ? parseFloat(distanceKm) : 10.5;

    const newBooking: Booking = {
      id: bookings.length ? Math.max(...bookings.map(b => b.id)) + 1 : 101,
      userId: currentUser.id,
      userName: currentUser.name,
      userPhone: currentUser.phone,
      cabId: cab.id,
      cabNumber: cab.cabNumber,
      cabType: cab.cabType,
      driverName: driver ? driver.name : 'John Smith',
      pickupLocation: pickup_location,
      destination,
      fare: computedFare,
      distanceKm: dist,
      bookingStatus: 'Pending',
      bookingDate: new Date().toISOString().replace('T', ' ').substring(0, 19)
    };

    bookings.unshift(newBooking);

    // Update Cab & Driver status
    cab.availability = 'On Ride';
    if (driver) {
      driver.status = 'Busy';
    }

    res.status(201).json(newBooking);
  });

  app.put('/api/bookings/:id/status', (req, res) => {
    const id = parseInt(req.params.id);
    const { booking_status } = req.body;

    const booking = bookings.find(b => b.id === id);
    if (!booking) {
      return res.status(404).json({ detail: 'Booking not found' });
    }

    booking.bookingStatus = booking_status;

    // Release Cab & Driver if Completed or Cancelled
    if (booking_status === 'Completed' || booking_status === 'Cancelled') {
      const cab = cabs.find(c => c.id === booking.cabId);
      if (cab) {
        cab.availability = 'Available';
        if (cab.driverId) {
          const driver = drivers.find(d => d.id === cab.driverId);
          if (driver) {
            driver.status = 'Available';
            if (booking_status === 'Completed') {
              driver.totalRides = (driver.totalRides || 0) + 1;
            }
          }
        }
      }
    }

    res.json(booking);
  });

  // System Analytics
  app.get('/api/stats', (req, res) => {
    res.json(getSystemStats());
  });

  // Source Code Explorer API Endpoint (allows viewing backend FastAPI files & standalone HTML/CSS/JS frontend)
  app.get('/api/source-code', (req, res) => {
    const filesToRead = [
      { key: 'main_py', path: '/AutoCab-System/backend/main.py', title: 'main.py (FastAPI Routes)', lang: 'python' },
      { key: 'database_py', path: '/AutoCab-System/backend/database.py', title: 'database.py (SQLAlchemy Engine)', lang: 'python' },
      { key: 'models_py', path: '/AutoCab-System/backend/models.py', title: 'models.py (Database Models)', lang: 'python' },
      { key: 'schemas_py', path: '/AutoCab-System/backend/schemas.py', title: 'schemas.py (Pydantic Validation)', lang: 'python' },
      { key: 'crud_py', path: '/AutoCab-System/backend/crud.py', title: 'crud.py (ORM Operations)', lang: 'python' },
      { key: 'auth_py', path: '/AutoCab-System/backend/auth.py', title: 'auth.py (JWT Security)', lang: 'python' },
      { key: 'requirements_txt', path: '/AutoCab-System/backend/requirements.txt', title: 'requirements.txt', lang: 'text' },
      { key: 'index_html', path: '/AutoCab-System/frontend/index.html', title: 'frontend/index.html', lang: 'html' },
      { key: 'style_css', path: '/AutoCab-System/frontend/style.css', title: 'frontend/style.css', lang: 'css' },
      { key: 'script_js', path: '/AutoCab-System/frontend/script.js', title: 'frontend/script.js', lang: 'javascript' },
      { key: 'readme_md', path: '/AutoCab-System/README.md', title: 'README.md (Setup Guide)', lang: 'markdown' }
    ];

    const sources: Record<string, { title: string; content: string; lang: string }> = {};

    for (const f of filesToRead) {
      try {
        const fullPath = path.join(process.cwd(), f.path);
        if (fs.existsSync(fullPath)) {
          sources[f.key] = {
            title: f.title,
            content: fs.readFileSync(fullPath, 'utf8'),
            lang: f.lang
          };
        }
      } catch (err) {
        console.error(`Error reading ${f.path}:`, err);
      }
    }

    res.json(sources);
  });

  // --- Vite Middleware for Development / Static Production Serving ---
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`AutoCab Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
