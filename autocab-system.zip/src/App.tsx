import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { HomePage } from './components/HomePage';
import { BookingPage } from './components/BookingPage';
import { UserDashboard } from './components/UserDashboard';
import { DriverDashboard } from './components/DriverDashboard';
import { AdminDashboard } from './components/AdminDashboard';
import { AuthModal } from './components/AuthModal';
import { CodeViewerModal } from './components/CodeViewerModal';
import { User, Driver, Cab, Booking, SystemStats, Role } from './types';
import {
  fetchCabsFirestore,
  fetchDriversFirestore,
  fetchUsersFirestore,
  fetchBookingsFirestore,
  fetchStatsFirestore,
  loginWithFirebaseAndFirestore,
  registerWithFirebaseAndFirestore,
  addBookingFirestore,
  updateBookingStatusFirestore,
  updateDriverStatusFirestore,
  deleteUserFirestore,
  addDriverFirestore,
  addCabFirestore,
  updateCabAvailabilityFirestore
} from './lib/firestoreService';

export default function App() {
  // Default logged in user: Emily Chen (Passenger)
  const [currentUser, setCurrentUser] = useState<User | null>({
    id: 4,
    name: 'Emily Chen',
    email: 'user@autocab.com',
    phone: '+1-555-0123',
    role: 'user'
  });

  const [activeTab, setActiveTab] = useState<string>('home');
  const [cabs, setCabs] = useState<Cab[]>([]);
  const [drivers, setDrivers] = useState<Driver[]>([]);
  const [usersList, setUsersList] = useState<User[]>([]);
  const [bookingsList, setBookingsList] = useState<Booking[]>([]);
  const [stats, setStats] = useState<SystemStats>({
    totalUsers: 5,
    totalDrivers: 4,
    totalCabs: 4,
    availableCabs: 2,
    totalBookings: 3,
    completedRides: 1,
    totalRevenue: 357.60
  });

  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [isCodeViewerOpen, setIsCodeViewerOpen] = useState(false);

  // Fetch initial data from Firebase Firestore
  const refreshData = async () => {
    try {
      const [cabsRes, driversRes, usersRes, bookingsRes, statsRes] = await Promise.all([
        fetchCabsFirestore(),
        fetchDriversFirestore(),
        fetchUsersFirestore(),
        fetchBookingsFirestore(),
        fetchStatsFirestore()
      ]);

      setCabs(cabsRes);
      setDrivers(driversRes);
      setUsersList(usersRes);
      setBookingsList(bookingsRes);
      setStats(statsRes);
    } catch (err) {
      console.error('Firestore fetch error, falling back to REST API:', err);
      // Fallback to Express backend endpoints
      try {
        const [cabsRes, driversRes, usersRes, bookingsRes, statsRes] = await Promise.all([
          fetch('/api/cabs').then(r => r.json()),
          fetch('/api/drivers').then(r => r.json()),
          fetch('/api/users').then(r => r.json()),
          fetch('/api/bookings/all').then(r => r.json()),
          fetch('/api/stats').then(r => r.json())
        ]);
        setCabs(cabsRes);
        setDrivers(driversRes);
        setUsersList(usersRes);
        setBookingsList(bookingsRes);
        setStats(statsRes);
      } catch (restErr) {
        console.error('REST API fetch error:', restErr);
      }
    }
  };

  useEffect(() => {
    refreshData();
  }, []);

  // Firebase + Firestore Login handler
  const handleLogin = async (email: string, pass: string) => {
    const user = await loginWithFirebaseAndFirestore(email, pass);
    setCurrentUser(user);
    if (user.role === 'admin') setActiveTab('admin-dashboard');
    else if (user.role === 'driver') setActiveTab('driver-dashboard');
    else setActiveTab('user-dashboard');
    await refreshData();
  };

  // Firebase + Firestore Register handler
  const handleRegister = async (name: string, email: string, phone: string, pass: string, role: Role) => {
    const user = await registerWithFirebaseAndFirestore(name, email, phone, pass, role);
    setCurrentUser(user);
    if (user.role === 'admin') setActiveTab('admin-dashboard');
    else if (user.role === 'driver') setActiveTab('driver-dashboard');
    else setActiveTab('user-dashboard');
    await refreshData();
  };

  // Quick 1-click role switcher
  const handleQuickRoleSwitch = (role: Role) => {
    if (role === 'admin') {
      setCurrentUser({ id: 1, name: 'Alex Rivera', email: 'admin@autocab.com', phone: '+1-555-0100', role: 'admin' });
      setActiveTab('admin-dashboard');
    } else if (role === 'driver') {
      setCurrentUser({ id: 2, name: 'John Smith', email: 'john.driver@autocab.com', phone: '+1-555-0199', role: 'driver' });
      setActiveTab('driver-dashboard');
    } else {
      setCurrentUser({ id: 4, name: 'Emily Chen', email: 'user@autocab.com', phone: '+1-555-0123', role: 'user' });
      setActiveTab('user-dashboard');
    }
  };

  // Book ride handler with Firestore
  const handleBookRide = async (bookingData: {
    cabId: number;
    pickupLocation: string;
    destination: string;
    fare: number;
    distanceKm: number;
  }) => {
    if (!currentUser) {
      setIsAuthOpen(true);
      return;
    }

    await addBookingFirestore({
      userId: currentUser.id,
      userName: currentUser.name,
      userPhone: currentUser.phone,
      cabId: bookingData.cabId,
      pickupLocation: bookingData.pickupLocation,
      destination: bookingData.destination,
      fare: bookingData.fare,
      distanceKm: bookingData.distanceKm
    });

    await refreshData();
  };

  // Cancel booking
  const handleCancelBooking = async (bookingId: number) => {
    await updateBookingStatusFirestore(bookingId, 'Cancelled');
    await refreshData();
  };

  // Update Driver status
  const handleUpdateDriverStatus = async (driverId: number, status: Driver['status']) => {
    await updateDriverStatusFirestore(driverId, status);
    await refreshData();
  };

  // Update Booking status
  const handleUpdateBookingStatus = async (bookingId: number, status: Booking['bookingStatus']) => {
    await updateBookingStatusFirestore(bookingId, status);
    await refreshData();
  };

  // Delete User
  const handleDeleteUser = async (userId: number) => {
    await deleteUserFirestore(userId);
    await refreshData();
  };

  // Add Driver
  const handleAddDriver = async (driverData: Partial<Driver>) => {
    await addDriverFirestore(driverData);
    await refreshData();
  };

  // Add Cab
  const handleAddCab = async (cabData: Partial<Cab>) => {
    await addCabFirestore(cabData);
    await refreshData();
  };

  // Update Cab Availability
  const handleUpdateCabAvailability = async (cabId: number, availability: Cab['availability']) => {
    await updateCabAvailabilityFirestore(cabId, availability);
    await refreshData();
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans antialiased flex flex-col">
      {/* Top Navbar */}
      <Navbar
        currentUser={currentUser}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenAuth={() => setIsAuthOpen(true)}
        onLogout={() => { setCurrentUser(null); setActiveTab('home'); }}
        onOpenCodeViewer={() => setIsCodeViewerOpen(true)}
        onQuickRoleSwitch={handleQuickRoleSwitch}
      />

      {/* Main Page View Router */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 pt-8">
        {activeTab === 'home' && (
          <HomePage
            onBookNow={() => setActiveTab('booking')}
            onViewCode={() => setIsCodeViewerOpen(true)}
            availableCabs={cabs}
          />
        )}

        {activeTab === 'booking' && (
          <BookingPage
            currentUser={currentUser}
            cabs={cabs}
            onBookRide={handleBookRide}
            onOpenAuth={() => setIsAuthOpen(true)}
          />
        )}

        {activeTab === 'user-dashboard' && (
          currentUser && currentUser.role === 'user' ? (
            <UserDashboard
              currentUser={currentUser}
              bookings={bookingsList.filter(b => b.userId === currentUser.id)}
              onCancelBooking={handleCancelBooking}
              onBookNewCab={() => setActiveTab('booking')}
            />
          ) : (
            <div className="bg-white rounded-3xl p-8 border border-slate-200 text-center max-w-lg mx-auto my-12 space-y-4 shadow-xl">
              <div className="w-12 h-12 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center mx-auto text-xl font-bold">
                👤
              </div>
              <h3 className="text-xl font-black text-slate-900">Passenger Login Required</h3>
              <p className="text-xs text-slate-500 leading-relaxed">
                You are currently logged in as {currentUser ? `${currentUser.name} (${currentUser.role})` : 'a guest'}.
                Please sign in with a passenger user account to view booking history.
              </p>
              <button
                onClick={() => setIsAuthOpen(true)}
                className="px-6 py-3 bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold rounded-xl transition-all shadow-lg shadow-blue-600/20"
              >
                Sign In as Passenger
              </button>
            </div>
          )
        )}

        {activeTab === 'driver-dashboard' && (
          currentUser && (currentUser.role === 'driver' || currentUser.role === 'admin') ? (
            <DriverDashboard
              currentUser={currentUser}
              driverInfo={drivers.find(d => d.name === currentUser.name) || drivers[0]}
              bookings={bookingsList}
              onUpdateDriverStatus={handleUpdateDriverStatus}
              onUpdateBookingStatus={handleUpdateBookingStatus}
            />
          ) : (
            <div className="bg-white rounded-3xl p-8 border border-slate-200 text-center max-w-lg mx-auto my-12 space-y-4 shadow-xl">
              <div className="w-12 h-12 rounded-full bg-amber-100 text-amber-600 flex items-center justify-center mx-auto text-xl font-bold">
                🚖
              </div>
              <h3 className="text-xl font-black text-slate-900">Driver Portal Authorization Needed</h3>
              <p className="text-xs text-slate-500 leading-relaxed">
                You are currently logged in as {currentUser ? `${currentUser.name} (${currentUser.role})` : 'a guest'}.
                Driver portal access requires authentication with registered Cab Driver credentials.
              </p>
              <button
                onClick={() => setIsAuthOpen(true)}
                className="px-6 py-3 bg-amber-600 hover:bg-amber-500 text-white text-xs font-bold rounded-xl transition-all shadow-lg shadow-amber-600/20"
              >
                Sign In as Driver
              </button>
            </div>
          )
        )}

        {activeTab === 'admin-dashboard' && (
          currentUser && currentUser.role === 'admin' ? (
            <AdminDashboard
              currentUser={currentUser}
              stats={stats}
              usersList={usersList}
              driversList={drivers}
              cabsList={cabs}
              bookingsList={bookingsList}
              onDeleteUser={handleDeleteUser}
              onAddDriver={handleAddDriver}
              onAddCab={handleAddCab}
              onUpdateCabAvailability={handleUpdateCabAvailability}
              onUpdateBookingStatus={handleUpdateBookingStatus}
            />
          ) : (
            <div className="bg-white rounded-3xl p-8 border border-slate-200 text-center max-w-lg mx-auto my-12 space-y-4 shadow-xl">
              <div className="w-12 h-12 rounded-full bg-purple-100 text-purple-600 flex items-center justify-center mx-auto text-xl font-bold">
                🛡️
              </div>
              <h3 className="text-xl font-black text-slate-900">Admin Portal Restricted</h3>
              <p className="text-xs text-slate-500 leading-relaxed">
                You are currently logged in as {currentUser ? `${currentUser.name} (${currentUser.role})` : 'a guest'}.
                Fleet Admin privileges are required to manage cabs, drivers, users, and overall system metrics.
              </p>
              <button
                onClick={() => setIsAuthOpen(true)}
                className="px-6 py-3 bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold rounded-xl transition-all shadow-lg shadow-purple-600/20"
              >
                Sign In as Admin
              </button>
            </div>
          )
        )}
      </main>

      {/* Footer */}
      <footer className="bg-slate-900 text-slate-400 border-t border-slate-800 py-8 text-center text-xs space-y-2">
        <p className="font-bold text-slate-300">🚖 AutoCab System — Powered by Firebase Firestore Database & Auth</p>
        <p>Built with React 19, Firebase Firestore, Express API Node Engine, and FastAPI SQLAlchemy Reference</p>
      </footer>

      {/* Modals */}
      <AuthModal
        isOpen={isAuthOpen}
        onClose={() => setIsAuthOpen(false)}
        onLogin={handleLogin}
        onRegister={handleRegister}
      />

      <CodeViewerModal
        isOpen={isCodeViewerOpen}
        onClose={() => setIsCodeViewerOpen(false)}
      />
    </div>
  );
}
