import {
  collection,
  getDocs,
  doc,
  setDoc,
  addDoc,
  updateDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  onSnapshot
} from 'firebase/firestore';
import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut,
  updateProfile
} from 'firebase/auth';
import { db, auth } from './firebase';
import { User, Driver, Cab, Booking, SystemStats, Role } from '../types';

// Default initial seed data for Firestore if collections are empty
const initialUsers: User[] = [
  { id: 1, name: 'Alex Rivera', email: 'admin@autocab.com', phone: '+1-555-0100', role: 'admin', createdAt: '2026-01-01 00:00:00' },
  { id: 2, name: 'John Smith', email: 'john.driver@autocab.com', phone: '+1-555-0199', role: 'driver', createdAt: '2026-01-02 00:00:00' },
  { id: 3, name: 'Sarah Jenkins', email: 'sarah.driver@autocab.com', phone: '+1-555-0188', role: 'driver', createdAt: '2026-01-03 00:00:00' },
  { id: 4, name: 'Emily Chen', email: 'user@autocab.com', phone: '+1-555-0123', role: 'user', createdAt: '2026-01-04 00:00:00' },
  { id: 5, name: 'Rajesh Kumar', email: 'rajesh@example.com', phone: '+91-9876543210', role: 'user', createdAt: '2026-01-05 00:00:00' }
];

const initialDrivers: Driver[] = [
  { id: 1, name: 'John Smith', phone: '+1-555-0199', licenseNumber: 'DL-88219-NY', status: 'Available', rating: 4.9, totalRides: 142 },
  { id: 2, name: 'Sarah Jenkins', phone: '+1-555-0188', licenseNumber: 'DL-99301-CA', status: 'Busy', rating: 4.8, totalRides: 98 },
  { id: 3, name: 'Michael Chang', phone: '+1-555-0177', licenseNumber: 'DL-44102-TX', status: 'Available', rating: 4.95, totalRides: 210 },
  { id: 4, name: 'Priya Sharma', phone: '+91-9876500112', licenseNumber: 'DL-11002-DL', status: 'Offline', rating: 4.7, totalRides: 55 }
];

const initialCabs: Cab[] = [
  { id: 1, driverId: 1, cabNumber: 'NY-7721', cabType: 'Sedan', availability: 'Available', fareRatePerKm: 18.00 },
  { id: 2, driverId: 2, cabNumber: 'CA-8832', cabType: 'SUV', availability: 'On Ride', fareRatePerKm: 25.00 },
  { id: 3, driverId: 3, cabNumber: 'TX-4410', cabType: 'Luxury', availability: 'Available', fareRatePerKm: 45.00 },
  { id: 4, driverId: 4, cabNumber: 'FL-9901', cabType: 'EV', availability: 'Maintenance', fareRatePerKm: 20.00 }
];

const initialBookings: Booking[] = [
  {
    id: 101,
    userId: 4,
    userName: 'Emily Chen',
    userPhone: '+1-555-0123',
    cabId: 1,
    cabNumber: 'NY-7721',
    cabType: 'Sedan',
    driverName: 'John Smith',
    pickupLocation: 'Downtown Central Station',
    destination: 'Airport Terminal 2',
    fare: 357.60,
    distanceKm: 18.2,
    bookingStatus: 'Completed',
    bookingDate: '2026-08-06 14:30:00'
  },
  {
    id: 102,
    userId: 4,
    userName: 'Emily Chen',
    userPhone: '+1-555-0123',
    cabId: 2,
    cabNumber: 'CA-8832',
    cabType: 'SUV',
    driverName: 'Sarah Jenkins',
    pickupLocation: 'Financial District',
    destination: 'Tech Park Plaza',
    fare: 215.00,
    distanceKm: 7.4,
    bookingStatus: 'In Progress',
    bookingDate: '2026-08-07 08:15:00'
  },
  {
    id: 103,
    userId: 5,
    userName: 'Rajesh Kumar',
    userPhone: '+91-9876543210',
    cabId: 3,
    cabNumber: 'TX-4410',
    cabType: 'Luxury',
    driverName: 'Michael Chang',
    pickupLocation: 'North Suburbs',
    destination: 'City Shopping Mall',
    fare: 322.50,
    distanceKm: 6.5,
    bookingStatus: 'Pending',
    bookingDate: '2026-08-07 09:00:00'
  }
];

// Helper to seed Firestore if empty
export async function seedFirestoreIfEmpty() {
  try {
    const usersSnap = await getDocs(collection(db, 'users'));
    if (usersSnap.empty) {
      console.log('Seeding initial users to Firestore...');
      for (const u of initialUsers) {
        await setDoc(doc(db, 'users', u.id.toString()), u);
      }
    }

    const driversSnap = await getDocs(collection(db, 'drivers'));
    if (driversSnap.empty) {
      console.log('Seeding initial drivers to Firestore...');
      for (const d of initialDrivers) {
        await setDoc(doc(db, 'drivers', d.id.toString()), d);
      }
    }

    const cabsSnap = await getDocs(collection(db, 'cabs'));
    if (cabsSnap.empty) {
      console.log('Seeding initial cabs to Firestore...');
      for (const c of initialCabs) {
        await setDoc(doc(db, 'cabs', c.id.toString()), c);
      }
    }

    const bookingsSnap = await getDocs(collection(db, 'bookings'));
    if (bookingsSnap.empty) {
      console.log('Seeding initial bookings to Firestore...');
      for (const b of initialBookings) {
        await setDoc(doc(db, 'bookings', b.id.toString()), b);
      }
    }
  } catch (err) {
    console.error('Firestore seed error:', err);
  }
}

// User Auth & Firestore Operations
export async function registerWithFirebaseAndFirestore(
  name: string,
  email: string,
  phone: string,
  pass: string,
  role: Role
): Promise<User> {
  // Check if email already exists in Firestore
  const q = query(collection(db, 'users'), where('email', '==', email.toLowerCase()));
  const existingDocs = await getDocs(q);
  if (!existingDocs.empty) {
    throw new Error('An account with this email already exists.');
  }

  let firebaseUid = '';
  try {
    const userCred = await createUserWithEmailAndPassword(auth, email, pass);
    if (userCred.user) {
      await updateProfile(userCred.user, { displayName: name });
      firebaseUid = userCred.user.uid;
    }
  } catch (err: any) {
    // If auth fails or account exists in Firebase Auth, proceed with firestore user creation
    console.log('Firebase Auth Notice:', err.message);
  }

  const allUsers = await fetchUsersFirestore();
  const nextId = allUsers.length ? Math.max(...allUsers.map(u => u.id)) + 1 : 1;

  const newUser: User = {
    id: nextId,
    name,
    email: email.toLowerCase(),
    phone: phone || '+91-9876500000',
    role: role || 'user',
    createdAt: new Date().toISOString()
  };

  await setDoc(doc(db, 'users', newUser.id.toString()), {
    ...newUser,
    firebaseUid
  });

  return newUser;
}

export async function loginWithFirebaseAndFirestore(email: string, pass: string): Promise<User> {
  // Try Firebase Auth login
  try {
    await signInWithEmailAndPassword(auth, email, pass);
  } catch (err: any) {
    console.log('Firebase auth login note:', err.message);
  }

  // Fetch user from Firestore
  const q = query(collection(db, 'users'), where('email', '==', email.toLowerCase()));
  const snap = await getDocs(q);

  if (snap.empty) {
    // Fallback search in hardcoded list or error
    const match = initialUsers.find(u => u.email.toLowerCase() === email.toLowerCase());
    if (match) return match;
    throw new Error('Invalid email address or user not registered in Firebase.');
  }

  const userData = snap.docs[0].data() as User;
  return userData;
}

// Fetch functions
export async function fetchUsersFirestore(): Promise<User[]> {
  await seedFirestoreIfEmpty();
  const snap = await getDocs(collection(db, 'users'));
  return snap.docs.map(d => d.data() as User);
}

export async function fetchDriversFirestore(): Promise<Driver[]> {
  await seedFirestoreIfEmpty();
  const snap = await getDocs(collection(db, 'drivers'));
  return snap.docs.map(d => d.data() as Driver);
}

export async function fetchCabsFirestore(): Promise<Cab[]> {
  await seedFirestoreIfEmpty();
  const snap = await getDocs(collection(db, 'cabs'));
  const cabsList = snap.docs.map(d => d.data() as Cab);
  const driversList = await fetchDriversFirestore();

  return cabsList.map(c => {
    const drv = driversList.find(d => d.id === c.driverId);
    return { ...c, driverName: drv ? drv.name : 'Unassigned' };
  });
}

export async function fetchBookingsFirestore(): Promise<Booking[]> {
  await seedFirestoreIfEmpty();
  const snap = await getDocs(collection(db, 'bookings'));
  const list = snap.docs.map(d => d.data() as Booking);
  return list.sort((a, b) => b.id - a.id);
}

export async function addBookingFirestore(bookingData: {
  userId: number;
  userName: string;
  userPhone: string;
  cabId: number;
  pickupLocation: string;
  destination: string;
  fare: number;
  distanceKm: number;
}): Promise<Booking> {
  const allBookings = await fetchBookingsFirestore();
  const cabsList = await fetchCabsFirestore();
  const driversList = await fetchDriversFirestore();

  const cab = cabsList.find(c => c.id === bookingData.cabId);
  if (!cab) throw new Error('Selected cab not found.');

  const driver = driversList.find(d => d.id === cab.driverId);
  const nextId = allBookings.length ? Math.max(...allBookings.map(b => b.id)) + 1 : 101;

  const newBooking: Booking = {
    id: nextId,
    userId: bookingData.userId,
    userName: bookingData.userName,
    userPhone: bookingData.userPhone,
    cabId: cab.id,
    cabNumber: cab.cabNumber,
    cabType: cab.cabType,
    driverName: driver ? driver.name : 'John Smith',
    pickupLocation: bookingData.pickupLocation,
    destination: bookingData.destination,
    fare: bookingData.fare,
    distanceKm: bookingData.distanceKm,
    bookingStatus: 'Pending',
    bookingDate: new Date().toISOString().replace('T', ' ').substring(0, 19)
  };

  await setDoc(doc(db, 'bookings', newBooking.id.toString()), newBooking);

  // Update Cab to On Ride
  await updateDoc(doc(db, 'cabs', cab.id.toString()), { availability: 'On Ride' });

  // Update Driver to Busy
  if (driver) {
    await updateDoc(doc(db, 'drivers', driver.id.toString()), { status: 'Busy' });
  }

  return newBooking;
}

export async function updateBookingStatusFirestore(bookingId: number, status: Booking['bookingStatus']) {
  await updateDoc(doc(db, 'bookings', bookingId.toString()), { bookingStatus: status });

  if (status === 'Completed' || status === 'Cancelled') {
    const bookingsList = await fetchBookingsFirestore();
    const targetBooking = bookingsList.find(b => b.id === bookingId);
    if (targetBooking) {
      await updateDoc(doc(db, 'cabs', targetBooking.cabId.toString()), { availability: 'Available' });
      const cabsList = await fetchCabsFirestore();
      const cab = cabsList.find(c => c.id === targetBooking.cabId);
      if (cab && cab.driverId) {
        const driversList = await fetchDriversFirestore();
        const drv = driversList.find(d => d.id === cab.driverId);
        if (drv) {
          const updates: any = { status: 'Available' };
          if (status === 'Completed') {
            updates.totalRides = (drv.totalRides || 0) + 1;
          }
          await updateDoc(doc(db, 'drivers', drv.id.toString()), updates);
        }
      }
    }
  }
}

export async function updateCabAvailabilityFirestore(cabId: number, availability: Cab['availability']) {
  await updateDoc(doc(db, 'cabs', cabId.toString()), { availability });
}

export async function updateDriverStatusFirestore(driverId: number, status: Driver['status']) {
  await updateDoc(doc(db, 'drivers', driverId.toString()), { status });
}

export async function deleteUserFirestore(userId: number) {
  await deleteDoc(doc(db, 'users', userId.toString()));
}

export async function addDriverFirestore(driverData: Partial<Driver>): Promise<Driver> {
  const driversList = await fetchDriversFirestore();
  const nextId = driversList.length ? Math.max(...driversList.map(d => d.id)) + 1 : 1;

  const newDriver: Driver = {
    id: nextId,
    name: driverData.name || 'New Driver',
    phone: driverData.phone || '+91-9876500000',
    licenseNumber: driverData.licenseNumber || 'DL-99000',
    status: driverData.status || 'Available',
    rating: 5.0,
    totalRides: 0
  };

  await setDoc(doc(db, 'drivers', newDriver.id.toString()), newDriver);
  return newDriver;
}

export async function addCabFirestore(cabData: Partial<Cab>): Promise<Cab> {
  const cabsList = await fetchCabsFirestore();
  const nextId = cabsList.length ? Math.max(...cabsList.map(c => c.id)) + 1 : 1;

  const newCab: Cab = {
    id: nextId,
    cabNumber: cabData.cabNumber || 'IN-0001',
    cabType: cabData.cabType || 'Sedan',
    driverId: cabData.driverId ? Number(cabData.driverId) : null,
    availability: 'Available',
    fareRatePerKm: cabData.fareRatePerKm ? Number(cabData.fareRatePerKm) : 18.00
  };

  await setDoc(doc(db, 'cabs', newCab.id.toString()), newCab);
  return newCab;
}

export async function fetchStatsFirestore(): Promise<SystemStats> {
  const [usersList, driversList, cabsList, bookingsList] = await Promise.all([
    fetchUsersFirestore(),
    fetchDriversFirestore(),
    fetchCabsFirestore(),
    fetchBookingsFirestore()
  ]);

  const availableCabs = cabsList.filter(c => c.availability === 'Available').length;
  const completedRides = bookingsList.filter(b => b.bookingStatus === 'Completed').length;
  const totalRevenue = bookingsList
    .filter(b => b.bookingStatus === 'Completed')
    .reduce((sum, b) => sum + b.fare, 0);

  return {
    totalUsers: usersList.length,
    totalDrivers: driversList.length,
    totalCabs: cabsList.length,
    availableCabs,
    totalBookings: bookingsList.length,
    completedRides,
    totalRevenue
  };
}
