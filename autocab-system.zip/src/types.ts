export type Role = 'user' | 'driver' | 'admin';

export interface User {
  id: number;
  name: string;
  email: string;
  phone: string;
  role: Role;
  createdAt?: string;
}

export interface Driver {
  id: number;
  name: string;
  phone: string;
  licenseNumber: string;
  status: 'Available' | 'Busy' | 'Offline';
  rating?: number;
  totalRides?: number;
}

export interface Cab {
  id: number;
  driverId: number | null;
  driverName?: string;
  cabNumber: string;
  cabType: 'Sedan' | 'SUV' | 'Luxury' | 'EV';
  availability: 'Available' | 'On Ride' | 'Maintenance';
  fareRatePerKm: number;
}

export interface Booking {
  id: number;
  userId: number;
  userName?: string;
  userPhone?: string;
  cabId: number;
  cabNumber?: string;
  cabType?: string;
  driverName?: string;
  pickupLocation: string;
  destination: string;
  fare: number;
  distanceKm: number;
  bookingStatus: 'Pending' | 'Accepted' | 'In Progress' | 'Completed' | 'Cancelled';
  bookingDate: string;
}

export interface SystemStats {
  totalUsers: number;
  totalDrivers: number;
  totalCabs: number;
  availableCabs: number;
  totalBookings: number;
  completedRides: number;
  totalRevenue: number;
}

export interface AuthState {
  user: User | null;
  token: string | null;
}
