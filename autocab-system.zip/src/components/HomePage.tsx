import React, { useState } from 'react';
import { Car, Zap, Shield, Sparkles, MapPin, DollarSign, Clock, Users, CheckCircle, ChevronRight, Code } from 'lucide-react';
import { Cab } from '../types';

interface HomePageProps {
  onBookNow: () => void;
  onViewCode: () => void;
  availableCabs: Cab[];
}

export const HomePage: React.FC<HomePageProps> = ({ onBookNow, onViewCode, availableCabs }) => {
  const [pickup, setPickup] = useState('');
  const [destination, setDestination] = useState('');
  const [selectedType, setSelectedType] = useState<'Sedan' | 'SUV' | 'Luxury' | 'EV'>('Sedan');
  const [distanceKm, setDistanceKm] = useState(12);

  const rates = { Sedan: 18.0, SUV: 25.0, Luxury: 45.0, EV: 20.0 };
  const estimatedFare = (distanceKm * rates[selectedType] + 30.0).toFixed(2);

  return (
    <div className="space-y-12 pb-16">
      
      {/* Hero Banner */}
      <section className="relative overflow-hidden bg-slate-900 rounded-3xl border border-slate-800 text-white p-8 sm:p-12 lg:p-16 shadow-2xl">
        <div className="absolute top-0 right-0 -mt-12 -mr-12 w-96 h-96 bg-blue-600/20 rounded-full blur-3xl pointer-events-none"></div>
        <div className="absolute bottom-0 left-1/3 -mb-12 w-80 h-80 bg-purple-600/20 rounded-full blur-3xl pointer-events-none"></div>

        <div className="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          <div className="lg:col-span-7 space-y-6">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 text-xs font-semibold">
              <Sparkles className="w-4 h-4" />
              <span>Full-Stack AutoCab Fleet Engine v1.0</span>
            </div>

            <h1 className="text-4xl sm:text-5xl font-black tracking-tight leading-none text-white">
              Smart Cab Booking & Fleet Management <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-indigo-300">System</span>
            </h1>

            <p className="text-slate-300 text-base sm:text-lg max-w-xl font-normal leading-relaxed">
              Book rides instantly, track live driver assignments, and administer multi-tier fleets with our FastAPI + SQLite backend and responsive full-stack platform.
            </p>

            <div className="flex flex-wrap gap-4 pt-2">
              <button
                onClick={onBookNow}
                className="px-6 py-3.5 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-2xl shadow-xl shadow-blue-600/30 flex items-center space-x-2 transition-all transform hover:-translate-y-0.5"
              >
                <span>Book a Ride Now</span>
                <ChevronRight className="w-5 h-5" />
              </button>

              <button
                onClick={onViewCode}
                className="px-6 py-3.5 bg-slate-800 hover:bg-slate-700 text-emerald-400 font-bold rounded-2xl border border-slate-700 flex items-center space-x-2 transition-all"
              >
                <Code className="w-5 h-5" />
                <span>Inspect Backend Sources</span>
              </button>
            </div>

            {/* Quick Feature Chips */}
            <div className="pt-4 flex flex-wrap gap-6 text-xs text-slate-400 font-medium border-t border-slate-800">
              <div className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-emerald-400" />
                <span>JWT Authentication</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-emerald-400" />
                <span>Role Authorization (User/Driver/Admin)</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-emerald-400" />
                <span>SQLAlchemy ORM + FastAPI</span>
              </div>
            </div>
          </div>

          {/* Quick Fare Estimator Widget */}
          <div className="lg:col-span-5 bg-slate-800/90 backdrop-blur-md p-6 rounded-2xl border border-slate-700/80 shadow-xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-700 pb-3">
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                <DollarSign className="w-5 h-5 text-emerald-400" />
                <span>Quick Fare Calculator</span>
              </h3>
              <span className="text-xs bg-slate-700 text-slate-300 px-2 py-1 rounded-md">Live Rates</span>
            </div>

            <div className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">Pickup Point</label>
                <div className="relative">
                  <MapPin className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
                  <input
                    type="text"
                    value={pickup}
                    onChange={(e) => setPickup(e.target.value)}
                    placeholder="e.g. Downtown Metro"
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl py-2.5 pl-9 pr-3 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">Destination</label>
                <div className="relative">
                  <MapPin className="w-4 h-4 absolute left-3 top-3 text-emerald-400" />
                  <input
                    type="text"
                    value={destination}
                    onChange={(e) => setDestination(e.target.value)}
                    placeholder="e.g. International Airport"
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl py-2.5 pl-9 pr-3 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">Vehicle Class</label>
                <div className="grid grid-cols-4 gap-2">
                  {(['Sedan', 'SUV', 'Luxury', 'EV'] as const).map(type => (
                    <button
                      key={type}
                      type="button"
                      onClick={() => setSelectedType(type)}
                      className={`py-1.5 px-2 rounded-lg text-xs font-bold transition-all ${
                        selectedType === type ? 'bg-blue-600 text-white shadow-md' : 'bg-slate-900 text-slate-400 hover:text-white'
                      }`}
                    >
                      {type}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <div className="flex justify-between text-xs text-slate-400 mb-1">
                  <span>Distance: {distanceKm} km</span>
                  <span>Base Rate: ₹{rates[selectedType]}/km</span>
                </div>
                <input
                  type="range"
                  min="2"
                  max="50"
                  value={distanceKm}
                  onChange={(e) => setDistanceKm(parseInt(e.target.value))}
                  className="w-full accent-blue-500"
                />
              </div>

              <div className="pt-2 border-t border-slate-700/80 flex items-center justify-between">
                <div>
                  <span className="text-xs text-slate-400 block">Estimated Fare</span>
                  <span className="text-2xl font-black text-emerald-400">₹{estimatedFare}</span>
                </div>
                <button
                  onClick={onBookNow}
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl shadow-md transition-all"
                >
                  Proceed to Book
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Fleet Categories */}
      <section className="space-y-6">
        <div className="text-center max-w-2xl mx-auto space-y-2">
          <h2 className="text-3xl font-black tracking-tight text-slate-900">Explore Our Fleet Categories</h2>
          <p className="text-slate-600 text-sm">Choose from our premium selection of maintained vehicles tailored for every urban commute.</p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition-all space-y-4">
            <div className="w-12 h-12 bg-blue-100 rounded-2xl flex items-center justify-center text-blue-600">
              <Car className="w-6 h-6" />
            </div>
            <div>
              <span className="text-xs font-bold text-blue-600 uppercase tracking-wider">Most Popular</span>
              <h3 className="text-xl font-bold text-slate-900">Sedan Comfort</h3>
              <p className="text-slate-500 text-xs mt-1">Economical 4-seater cars for quick daily city travel with top safety standards.</p>
            </div>
            <div className="pt-2 border-t border-slate-100 flex justify-between text-xs font-bold text-slate-700">
              <span>Rate: ₹18.00 / km</span>
              <span className="text-emerald-600 font-semibold">4 Cabs Ready</span>
            </div>
          </div>

          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition-all space-y-4">
            <div className="w-12 h-12 bg-purple-100 rounded-2xl flex items-center justify-center text-purple-600">
              <Users className="w-6 h-6" />
            </div>
            <div>
              <span className="text-xs font-bold text-purple-600 uppercase tracking-wider">Family & Group</span>
              <h3 className="text-xl font-bold text-slate-900">SUV XL</h3>
              <p className="text-slate-500 text-xs mt-1">Spacious 6-seater vehicles perfect for luggage, airport runs, and family outings.</p>
            </div>
            <div className="pt-2 border-t border-slate-100 flex justify-between text-xs font-bold text-slate-700">
              <span>Rate: ₹25.00 / km</span>
              <span className="text-emerald-600 font-semibold">3 Cabs Ready</span>
            </div>
          </div>

          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition-all space-y-4">
            <div className="w-12 h-12 bg-amber-100 rounded-2xl flex items-center justify-center text-amber-600">
              <Sparkles className="w-6 h-6" />
            </div>
            <div>
              <span className="text-xs font-bold text-amber-600 uppercase tracking-wider">Executive VIP</span>
              <h3 className="text-xl font-bold text-slate-900">Luxury Class</h3>
              <p className="text-slate-500 text-xs mt-1">Premium luxury sedans with leather interiors for corporate executives.</p>
            </div>
            <div className="pt-2 border-t border-slate-100 flex justify-between text-xs font-bold text-slate-700">
              <span>Rate: ₹45.00 / km</span>
              <span className="text-emerald-600 font-semibold">2 Cabs Ready</span>
            </div>
          </div>

          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition-all space-y-4">
            <div className="w-12 h-12 bg-emerald-100 rounded-2xl flex items-center justify-center text-emerald-600">
              <Zap className="w-6 h-6" />
            </div>
            <div>
              <span className="text-xs font-bold text-emerald-600 uppercase tracking-wider">Zero Emission</span>
              <h3 className="text-xl font-bold text-slate-900">Electric EV</h3>
              <p className="text-slate-500 text-xs mt-1">Quiet, eco-friendly electric rides designed for sustainable smart cities.</p>
            </div>
            <div className="pt-2 border-t border-slate-100 flex justify-between text-xs font-bold text-slate-700">
              <span>Rate: ₹20.00 / km</span>
              <span className="text-emerald-600 font-semibold">2 Cabs Ready</span>
            </div>
          </div>

        </div>
      </section>

      {/* System Features */}
      <section className="bg-slate-100/80 rounded-3xl p-8 border border-slate-200">
        <h2 className="text-2xl font-black text-slate-900 text-center mb-8">Architecture & Platform Capabilities</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-white p-6 rounded-2xl border border-slate-200/80 space-y-3">
            <div className="w-10 h-10 bg-blue-50 text-blue-600 rounded-xl flex items-center justify-center font-bold">1</div>
            <h4 className="font-bold text-slate-900 text-base">User & Driver Authorization</h4>
            <p className="text-xs text-slate-600 leading-relaxed">
              Implemented JWT token verification and role-based access control protecting User, Driver, and Admin REST endpoints.
            </p>
          </div>

          <div className="bg-white p-6 rounded-2xl border border-slate-200/80 space-y-3">
            <div className="w-10 h-10 bg-blue-50 text-blue-600 rounded-xl flex items-center justify-center font-bold">2</div>
            <h4 className="font-bold text-slate-900 text-base">SQLAlchemy ORM Models</h4>
            <p className="text-xs text-slate-600 leading-relaxed">
              Relational schemas mapping Users, Drivers, Cabs, and Bookings with foreign keys and database relationship cascade constraints.
            </p>
          </div>

          <div className="bg-white p-6 rounded-2xl border border-slate-200/80 space-y-3">
            <div className="w-10 h-10 bg-blue-50 text-blue-600 rounded-xl flex items-center justify-center font-bold">3</div>
            <h4 className="font-bold text-slate-900 text-base">Full Fleet Administration</h4>
            <p className="text-xs text-slate-600 leading-relaxed">
              Real-time driver status tracking (Available / Busy / Offline), cab availability updates, and booking status controls.
            </p>
          </div>
        </div>
      </section>

    </div>
  );
};
