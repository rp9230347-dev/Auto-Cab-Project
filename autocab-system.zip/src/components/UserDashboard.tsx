import React, { useState } from 'react';
import { User, Booking } from '../types';
import { MapPin, DollarSign, Clock, Calendar, AlertCircle, XCircle, CheckCircle2, Car } from 'lucide-react';

interface UserDashboardProps {
  currentUser: User;
  bookings: Booking[];
  onCancelBooking: (bookingId: number) => Promise<void>;
  onBookNewCab: () => void;
}

export const UserDashboard: React.FC<UserDashboardProps> = ({
  currentUser,
  bookings,
  onCancelBooking,
  onBookNewCab
}) => {
  const [selectedReceipt, setSelectedReceipt] = useState<Booking | null>(null);

  const activeBookings = bookings.filter(b => b.bookingStatus === 'Pending' || b.bookingStatus === 'Accepted' || b.bookingStatus === 'In Progress');
  const pastBookings = bookings.filter(b => b.bookingStatus === 'Completed' || b.bookingStatus === 'Cancelled');

  const getStatusBadge = (status: Booking['bookingStatus']) => {
    switch (status) {
      case 'Pending':
        return <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-amber-100 text-amber-800">Pending Dispatch</span>;
      case 'Accepted':
        return <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-blue-100 text-blue-800">Driver En Route</span>;
      case 'In Progress':
        return <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-indigo-100 text-indigo-800">Trip In Progress</span>;
      case 'Completed':
        return <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800">Completed</span>;
      case 'Cancelled':
        return <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-rose-100 text-rose-800">Cancelled</span>;
      default:
        return null;
    }
  };

  return (
    <div className="space-y-8 pb-12">
      
      {/* Profile Header */}
      <div className="bg-slate-900 text-white rounded-3xl p-8 border border-slate-800 shadow-xl flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <div className="flex items-center gap-3">
            <h1 className="text-3xl font-black tracking-tight">{currentUser.name}'s Dashboard</h1>
            <span className="bg-blue-500/20 text-blue-400 text-xs font-bold px-2.5 py-0.5 rounded-full border border-blue-500/30 uppercase">Passenger</span>
          </div>
          <p className="text-slate-400 text-sm mt-1">Email: {currentUser.email} | Phone: {currentUser.phone}</p>
        </div>

        <button
          onClick={onBookNewCab}
          className="px-5 py-3 bg-blue-600 hover:bg-blue-500 text-white font-bold text-sm rounded-2xl shadow-lg shadow-blue-600/30 transition-all"
        >
          Book a New Cab
        </button>
      </div>

      {/* Active Rides Tracker Section */}
      <div className="space-y-4">
        <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2">
          <Car className="w-5 h-5 text-blue-600" />
          <span>Active & In-Progress Trips ({activeBookings.length})</span>
        </h2>

        {activeBookings.length === 0 ? (
          <div className="bg-white p-8 rounded-2xl border border-slate-200 text-center space-y-3">
            <CheckCircle2 className="w-10 h-10 text-emerald-500 mx-auto" />
            <h3 className="font-bold text-slate-900 text-base">No active rides right now</h3>
            <p className="text-xs text-slate-500">Need a ride? Book a cab in seconds with live dispatching.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {activeBookings.map(ride => (
              <div key={ride.id} className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
                <div className="flex justify-between items-start border-b border-slate-100 pb-3">
                  <div>
                    <span className="text-xs font-mono font-bold text-slate-400">BOOKING #{ride.id}</span>
                    <h4 className="font-bold text-slate-900 text-lg">{ride.cabType} Cab ({ride.cabNumber || 'Auto-Assigned'})</h4>
                  </div>
                  {getStatusBadge(ride.bookingStatus)}
                </div>

                <div className="space-y-2 text-sm text-slate-700">
                  <div className="flex items-start gap-2">
                    <MapPin className="w-4 h-4 text-blue-600 mt-1 flex-shrink-0" />
                    <div>
                      <span className="text-xs font-bold text-slate-400 block uppercase">Pickup</span>
                      <span className="font-medium text-slate-900">{ride.pickupLocation}</span>
                    </div>
                  </div>

                  <div className="flex items-start gap-2">
                    <MapPin className="w-4 h-4 text-emerald-600 mt-1 flex-shrink-0" />
                    <div>
                      <span className="text-xs font-bold text-slate-400 block uppercase">Destination</span>
                      <span className="font-medium text-slate-900">{ride.destination}</span>
                    </div>
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
                  <div>
                    <span className="text-xs text-slate-400 block">Total Fare</span>
                    <span className="text-xl font-black text-emerald-600">₹{ride.fare.toFixed(2)}</span>
                  </div>

                  {ride.bookingStatus === 'Pending' && (
                    <button
                      onClick={() => onCancelBooking(ride.id)}
                      className="px-3.5 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-600 font-bold text-xs rounded-xl border border-rose-200 transition-all flex items-center gap-1"
                    >
                      <XCircle className="w-4 h-4" />
                      <span>Cancel Ride</span>
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Booking History Table */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden space-y-4 p-6">
        <h2 className="text-xl font-bold text-slate-900">Trip History ({pastBookings.length})</h2>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm text-slate-700">
            <thead className="bg-slate-50 text-xs font-bold text-slate-500 uppercase tracking-wider border-b border-slate-200">
              <tr>
                <th className="p-3">Ride ID</th>
                <th className="p-3">Pickup</th>
                <th className="p-3">Destination</th>
                <th className="p-3">Driver</th>
                <th className="p-3">Fare</th>
                <th className="p-3">Status</th>
                <th className="p-3">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {pastBookings.length === 0 ? (
                <tr>
                  <td colSpan={7} className="p-6 text-center text-slate-400 text-xs">No completed or cancelled rides in history.</td>
                </tr>
              ) : (
                pastBookings.map(b => (
                  <tr key={b.id} className="hover:bg-slate-50/50 transition-colors">
                    <td className="p-3 font-mono font-bold text-slate-900">#{b.id}</td>
                    <td className="p-3 max-w-xs truncate">{b.pickupLocation}</td>
                    <td className="p-3 max-w-xs truncate">{b.destination}</td>
                    <td className="p-3 font-medium">{b.driverName || 'N/A'}</td>
                    <td className="p-3 font-black text-slate-900">₹{b.fare.toFixed(2)}</td>
                    <td className="p-3">{getStatusBadge(b.bookingStatus)}</td>
                    <td className="p-3">
                      <button
                        onClick={() => setSelectedReceipt(b)}
                        className="text-xs font-bold text-blue-600 hover:underline"
                      >
                        View Receipt
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Receipt Modal */}
      {selectedReceipt && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-8 max-w-md w-full shadow-2xl space-y-6">
            <div className="border-b border-slate-200 pb-4 text-center">
              <span className="text-xs font-mono font-bold text-slate-400">AUTOCAB SYSTEM RECEIPT</span>
              <h3 className="text-2xl font-black text-slate-900">Booking #{selectedReceipt.id}</h3>
              <p className="text-xs text-slate-500 mt-1">{selectedReceipt.bookingDate}</p>
            </div>

            <div className="space-y-3 text-sm">
              <div className="flex justify-between">
                <span className="text-slate-500">Passenger Name:</span>
                <span className="font-bold text-slate-900">{currentUser.name}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Vehicle Type:</span>
                <span className="font-bold text-slate-900">{selectedReceipt.cabType} ({selectedReceipt.cabNumber})</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Pickup:</span>
                <span className="font-bold text-slate-900 max-w-[200px] truncate">{selectedReceipt.pickupLocation}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Destination:</span>
                <span className="font-bold text-slate-900 max-w-[200px] truncate">{selectedReceipt.destination}</span>
              </div>
              <div className="pt-3 border-t border-slate-100 flex justify-between items-center text-base">
                <span className="font-bold text-slate-700">Total Paid:</span>
                <span className="text-2xl font-black text-emerald-600">₹{selectedReceipt.fare.toFixed(2)}</span>
              </div>
            </div>

            <button
              onClick={() => setSelectedReceipt(null)}
              className="w-full py-3 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-xl transition-all"
            >
              Close Receipt
            </button>
          </div>
        </div>
      )}

    </div>
  );
};
