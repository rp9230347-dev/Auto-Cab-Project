import React, { useState, useEffect } from 'react';
import { X, Code, Copy, Check, FileText, Download } from 'lucide-react';

interface CodeViewerModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const CodeViewerModal: React.FC<CodeViewerModalProps> = ({ isOpen, onClose }) => {
  const [sources, setSources] = useState<Record<string, { title: string; content: string; lang: string }>>({});
  const [selectedKey, setSelectedKey] = useState<string>('main_py');
  const [copied, setCopied] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (isOpen) {
      setLoading(true);
      fetch('/api/source-code')
        .then(res => res.json())
        .then(data => {
          setSources(data);
          setLoading(false);
        })
        .catch(err => {
          console.error(err);
          setLoading(false);
        });
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const currentFile = sources[selectedKey];

  const handleCopy = () => {
    if (currentFile) {
      navigator.clipboard.writeText(currentFile.content);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/80 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-slate-900 text-slate-100 rounded-3xl w-full max-w-5xl h-[85vh] border border-slate-800 shadow-2xl flex flex-col overflow-hidden">
        
        {/* Header */}
        <div className="p-5 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-emerald-500/10 text-emerald-400 rounded-xl border border-emerald-500/20">
              <Code className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-black text-white text-lg tracking-tight">Backend & Frontend Source Inspector</h3>
              <p className="text-xs text-slate-400">Complete generated Python FastAPI, SQLAlchemy ORM, and HTML/CSS/JS frontend code</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-slate-800 text-slate-400 hover:text-white hover:bg-slate-700 transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Layout */}
        <div className="flex-1 grid grid-cols-1 md:grid-cols-12 overflow-hidden">
          
          {/* File Tree Sidebar */}
          <div className="md:col-span-4 bg-slate-950/60 p-4 border-r border-slate-800/80 overflow-y-auto space-y-4">
            <div>
              <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-purple-400 px-2 block mb-2">🐍 Python FastAPI Backend</span>
              <div className="space-y-1">
                {[
                  { key: 'main_py', label: 'main.py' },
                  { key: 'database_py', label: 'database.py' },
                  { key: 'models_py', label: 'models.py' },
                  { key: 'schemas_py', label: 'schemas.py' },
                  { key: 'crud_py', label: 'crud.py' },
                  { key: 'auth_py', label: 'auth.py' },
                  { key: 'requirements_txt', label: 'requirements.txt' }
                ].map(item => (
                  <button
                    key={item.key}
                    onClick={() => setSelectedKey(item.key)}
                    className={`w-full text-left px-3 py-2 rounded-xl text-xs font-mono transition-all flex items-center space-x-2 ${
                      selectedKey === item.key ? 'bg-purple-600/20 text-purple-300 font-bold border border-purple-500/30' : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
                    }`}
                  >
                    <FileText className="w-4 h-4 flex-shrink-0" />
                    <span>{item.label}</span>
                  </button>
                ))}
              </div>
            </div>

            <div>
              <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-blue-400 px-2 block mb-2">🌐 Standalone Frontend</span>
              <div className="space-y-1">
                {[
                  { key: 'index_html', label: 'frontend/index.html' },
                  { key: 'style_css', label: 'frontend/style.css' },
                  { key: 'script_js', label: 'frontend/script.js' },
                  { key: 'readme_md', label: 'README.md (Setup Guide)' }
                ].map(item => (
                  <button
                    key={item.key}
                    onClick={() => setSelectedKey(item.key)}
                    className={`w-full text-left px-3 py-2 rounded-xl text-xs font-mono transition-all flex items-center space-x-2 ${
                      selectedKey === item.key ? 'bg-blue-600/20 text-blue-300 font-bold border border-blue-500/30' : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
                    }`}
                  >
                    <FileText className="w-4 h-4 flex-shrink-0" />
                    <span>{item.label}</span>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Code View Area */}
          <div className="md:col-span-8 flex flex-col bg-slate-900 overflow-hidden">
            <div className="p-3 bg-slate-950/40 border-b border-slate-800/80 flex items-center justify-between px-6">
              <span className="text-xs font-mono font-bold text-slate-300">
                {currentFile ? currentFile.title : 'Loading...'}
              </span>

              <button
                onClick={handleCopy}
                disabled={!currentFile}
                className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold rounded-lg border border-slate-700 flex items-center space-x-1.5 transition-all"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copied!' : 'Copy File Content'}</span>
              </button>
            </div>

            <div className="flex-1 p-6 overflow-auto font-mono text-xs leading-relaxed text-slate-300 bg-slate-950/90">
              {loading ? (
                <div className="text-center py-12 text-slate-500">Loading source code...</div>
              ) : currentFile ? (
                <pre className="whitespace-pre-wrap">{currentFile.content}</pre>
              ) : (
                <div className="text-center py-12 text-slate-500">Select a file from the sidebar to inspect content.</div>
              )}
            </div>
          </div>

        </div>

      </div>
    </div>
  );
};
