import React, { useState } from 'react';
import { Car, MapPin, DollarSign, Clock, CheckCircle2, Shield, AlertCircle, ArrowRight } from 'lucide-react';
import { Cab, User } from '../types';

interface BookingPageProps {
  currentUser: User | null;
  cabs: Cab[];
  onBookRide: (bookingData: {
    cabId: number;
    pickupLocation: string;
    destination: string;
    fare: number;
    distanceKm: number;
  }) => Promise<void>;
  onOpenAuth: () => void;
}

export const BookingPage: React.FC<BookingPageProps> = ({
  currentUser,
  cabs,
  onBookRide,
  onOpenAuth
}) => {
  const [pickup, setPickup] = useState('');
  const [destination, setDestination] = useState('');
  const [selectedCabType, setSelectedCabType] = useState<string>('All');
  const [selectedCabId, setSelectedCabId] = useState<number | null>(null);
  const [distanceKm, setDistanceKm] = useState(14);
  const [loading, setLoading] = useState(false);
  const [successModal, setSuccessModal] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  // Filter available cabs
  const availableCabs = cabs.filter(c => {
    const isAvail = c.availability === 'Available';
    if (selectedCabType === 'All') return isAvail;
    return isAvail && c.cabType === selectedCabType;
  });

  const selectedCab = cabs.find(c => c.id === selectedCabId) || availableCabs[0];
  const currentRate = selectedCab ? selectedCab.fareRatePerKm : 18.00;
  const calculatedFare = parseFloat((distanceKm * currentRate + 30.0).toFixed(2));

  const handleSubmitBooking = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) {
      onOpenAuth();
      return;
    }

    if (!pickup.trim() || !destination.trim()) {
      setErrorMsg('Please enter both pickup and destination locations.');
      return;
    }

    const cabToBook = selectedCab || availableCabs[0];
    if (!cabToBook) {
      setErrorMsg('No available cab selected.');
      return;
    }

    try {
      setLoading(true);
      setErrorMsg('');
      await onBookRide({
        cabId: cabToBook.id,
        pickupLocation: pickup,
        destination,
        fare: calculatedFare,
        distanceKm
      });
      setSuccessModal(true);
      setPickup('');
      setDestination('');
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to place cab booking.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-6xl mx-auto space-y-8 pb-12">
      
      {/* Page Header */}
      <div className="bg-slate-900 text-white rounded-3xl p-8 border border-slate-800 shadow-xl flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-black tracking-tight">Book Your AutoCab</h1>
          <p className="text-slate-400 text-sm mt-1">Select pickup point, compare available cabs, and confirm your booking instantly.</p>
        </div>
        {!currentUser && (
          <button
            onClick={onOpenAuth}
            className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold rounded-xl shadow-md transition-all"
          >
            Sign in to Book Fast
          </button>
        )}
      </div>

      {errorMsg && (
        <div className="p-4 bg-red-50 border border-red-200 text-red-700 rounded-2xl text-sm flex items-center gap-2">
          <AlertCircle className="w-5 h-5 flex-shrink-0" />
          <span>{errorMsg}</span>
        </div>
      )}

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left Form: Booking Details */}
        <div className="lg:col-span-5 bg-white p-6 sm:p-8 rounded-3xl border border-slate-200 shadow-sm space-y-6">
          <h2 className="text-xl font-bold text-slate-900 border-b border-slate-100 pb-3 flex items-center gap-2">
            <Car className="w-5 h-5 text-blue-600" />
            <span>Trip & Location Details</span>
          </h2>

          <form onSubmit={handleSubmitBooking} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">Pickup Location</label>
              <div className="relative">
                <MapPin className="w-5 h-5 absolute left-3 top-3 text-blue-600" />
                <input
                  type="text"
                  required
                  value={pickup}
                  onChange={(e) => setPickup(e.target.value)}
                  placeholder="e.g. 742 Evergreen Terrace, Springfield"
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl py-3 pl-10 pr-3 text-sm text-slate-900 placeholder-slate-400 focus:outline-none focus:border-blue-600 focus:bg-white transition-all"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">Destination</label>
              <div className="relative">
                <MapPin className="w-5 h-5 absolute left-3 top-3 text-emerald-600" />
                <input
                  type="text"
                  required
                  value={destination}
                  onChange={(e) => setDestination(e.target.value)}
                  placeholder="e.g. Metro Airport Terminal 3"
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl py-3 pl-10 pr-3 text-sm text-slate-900 placeholder-slate-400 focus:outline-none focus:border-blue-600 focus:bg-white transition-all"
                />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-xs text-slate-600 font-bold mb-1">
                <span>Estimated Distance: {distanceKm} km</span>
                <span>Rate: ₹{currentRate}/km</span>
              </div>
              <input
                type="range"
                min="3"
                max="60"
                value={distanceKm}
                onChange={(e) => setDistanceKm(parseInt(e.target.value))}
                className="w-full accent-blue-600"
              />
            </div>

            {/* Fare Summary Box */}
            <div className="p-4 bg-slate-900 text-white rounded-2xl space-y-2">
              <div className="flex justify-between text-xs text-slate-400">
                <span>Base Booking Charge</span>
                <span>₹30.00</span>
              </div>
              <div className="flex justify-between text-xs text-slate-400">
                <span>Distance Rate ({distanceKm} km × ₹{currentRate})</span>
                <span>₹{(distanceKm * currentRate).toFixed(2)}</span>
              </div>
              <div className="pt-2 border-t border-slate-800 flex justify-between items-center">
                <span className="text-sm font-bold text-slate-200">Total Calculated Fare</span>
                <span className="text-2xl font-black text-emerald-400">₹{calculatedFare}</span>
              </div>
            </div>

            <button
              type="submit"
              disabled={loading || availableCabs.length === 0}
              className="w-full py-4 bg-blue-600 hover:bg-blue-500 disabled:bg-slate-300 text-white font-bold rounded-2xl shadow-lg shadow-blue-600/25 transition-all flex items-center justify-center space-x-2"
            >
              {loading ? (
                <span>Processing Booking...</span>
              ) : (
                <>
                  <span>Confirm Cab Booking</span>
                  <ArrowRight className="w-5 h-5" />
                </>
              )}
            </button>
          </form>
        </div>

        {/* Right Section: Available Cabs Selection */}
        <div className="lg:col-span-7 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-2 bg-white p-4 rounded-2xl border border-slate-200">
            <h3 className="font-bold text-slate-900 text-base">Select Available Cab ({availableCabs.length})</h3>
            <div className="flex gap-1">
              {(['All', 'Sedan', 'SUV', 'Luxury', 'EV'] as const).map(type => (
                <button
                  key={type}
                  onClick={() => setSelectedCabType(type)}
                  className={`px-3 py-1 rounded-lg text-xs font-bold transition-all ${
                    selectedCabType === type ? 'bg-blue-600 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {type}
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-3">
            {availableCabs.length === 0 ? (
              <div className="bg-white p-8 rounded-2xl border border-slate-200 text-center space-y-2">
                <Car className="w-10 h-10 text-slate-400 mx-auto" />
                <p className="text-slate-700 font-bold">No available cabs found in this category right now.</p>
                <p className="text-xs text-slate-500">Please select 'All' or choose another category.</p>
              </div>
            ) : (
              availableCabs.map(cab => {
                const isSelected = (selectedCabId === cab.id) || (!selectedCabId && cab.id === availableCabs[0].id);
                return (
                  <div
                    key={cab.id}
                    onClick={() => setSelectedCabId(cab.id)}
                    className={`p-5 rounded-2xl border-2 cursor-pointer transition-all flex items-center justify-between ${
                      isSelected
                        ? 'bg-blue-50/50 border-blue-600 shadow-md'
                        : 'bg-white border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    <div className="flex items-center space-x-4">
                      <div className={`w-12 h-12 rounded-2xl flex items-center justify-center font-bold text-lg ${
                        isSelected ? 'bg-blue-600 text-white' : 'bg-slate-100 text-slate-700'
                      }`}>
                        🚖
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <h4 className="font-bold text-slate-900 text-base">{cab.cabType} Cab</h4>
                          <span className="text-xs font-mono font-bold bg-slate-100 text-slate-700 px-2 py-0.5 rounded">
                            {cab.cabNumber}
                          </span>
                        </div>
                        <p className="text-xs text-slate-500 mt-0.5">
                          Driver: <span className="font-semibold text-slate-700">{cab.driverName || 'Assigned On Dispatch'}</span>
                        </p>
                      </div>
                    </div>

                    <div className="text-right">
                      <span className="text-xs text-slate-500 block">Rate</span>
                      <span className="text-lg font-black text-slate-900">₹{cab.fareRatePerKm}/km</span>
                      <div className="mt-1">
                        <span className="inline-block text-[10px] uppercase font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                          {cab.availability}
                        </span>
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

      </div>

      {/* Success Modal */}
      {successModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-8 max-w-md w-full shadow-2xl text-center space-y-4">
            <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-10 h-10" />
            </div>
            <h3 className="text-2xl font-black text-slate-900">Cab Booked Successfully!</h3>
            <p className="text-slate-600 text-sm">
              Your ride dispatch request has been logged into the AutoCab SQLite Database. You can track ride progress on your user dashboard.
            </p>
            <button
              onClick={() => setSuccessModal(false)}
              className="w-full py-3 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl transition-all"
            >
              Back to Dashboard
            </button>
          </div>
        </div>
      )}

    </div>
  );
};
