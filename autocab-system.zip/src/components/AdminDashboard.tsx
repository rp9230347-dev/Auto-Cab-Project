import React, { useState } from 'react';
import { User, Driver, Cab, Booking, SystemStats } from '../types';
import { Users, Car, Shield, DollarSign, Plus, Trash2, Edit, RefreshCw, CheckCircle, AlertTriangle } from 'lucide-react';

interface AdminDashboardProps {
  currentUser: User;
  stats: SystemStats;
  usersList: User[];
  driversList: Driver[];
  cabsList: Cab[];
  bookingsList: Booking[];
  onDeleteUser: (userId: number) => Promise<void>;
  onAddDriver: (driverData: Partial<Driver>) => Promise<void>;
  onAddCab: (cabData: Partial<Cab>) => Promise<void>;
  onUpdateCabAvailability: (cabId: number, availability: Cab['availability']) => Promise<void>;
  onUpdateBookingStatus: (bookingId: number, status: Booking['bookingStatus']) => Promise<void>;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  currentUser,
  stats,
  usersList,
  driversList,
  cabsList,
  bookingsList,
  onDeleteUser,
  onAddDriver,
  onAddCab,
  onUpdateCabAvailability,
  onUpdateBookingStatus
}) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'users' | 'drivers' | 'cabs' | 'bookings'>('overview');

  // New Driver Form State
  const [showDriverModal, setShowDriverModal] = useState(false);
  const [driverName, setDriverName] = useState('');
  const [driverPhone, setDriverPhone] = useState('');
  const [driverLicense, setDriverLicense] = useState('');

  // New Cab Form State
  const [showCabModal, setShowCabModal] = useState(false);
  const [cabNumber, setCabNumber] = useState('');
  const [cabType, setCabType] = useState<'Sedan' | 'SUV' | 'Luxury' | 'EV'>('Sedan');
  const [assignedDriverId, setAssignedDriverId] = useState<string>('');
  const [cabRate, setCabRate] = useState<string>('18.00');

  const handleCreateDriver = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!driverName || !driverLicense) return;
    await onAddDriver({
      name: driverName,
      phone: driverPhone || '+1-555-0199',
      licenseNumber: driverLicense,
      status: 'Available'
    });
    setDriverName('');
    setDriverPhone('');
    setDriverLicense('');
    setShowDriverModal(false);
  };

  const handleCreateCab = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!cabNumber) return;
    await onAddCab({
      cabNumber,
      cabType,
      driverId: assignedDriverId ? parseInt(assignedDriverId) : null,
      fareRatePerKm: parseFloat(cabRate)
    });
    setCabNumber('');
    setAssignedDriverId('');
    setShowCabModal(false);
  };

  return (
    <div className="space-y-8 pb-12">
      
      {/* Admin Header */}
      <div className="bg-slate-900 text-white rounded-3xl p-8 border border-slate-800 shadow-xl flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <div className="flex items-center gap-3">
            <h1 className="text-3xl font-black tracking-tight">Fleet Admin Portal</h1>
            <span className="bg-purple-500/20 text-purple-300 text-xs font-bold px-2.5 py-0.5 rounded-full border border-purple-500/30 uppercase">Super Admin</span>
          </div>
          <p className="text-slate-400 text-sm mt-1">Manage users, drivers, vehicle allocations, and global revenue logs.</p>
        </div>

        {/* Tab Switcher */}
        <div className="flex flex-wrap gap-1 bg-slate-800 p-1.5 rounded-2xl border border-slate-700">
          {(['overview', 'users', 'drivers', 'cabs', 'bookings'] as const).map(tab => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold capitalize transition-all ${
                activeTab === tab ? 'bg-purple-600 text-white shadow-md' : 'text-slate-400 hover:text-white'
              }`}
            >
              {tab}
            </button>
          ))}
        </div>
      </div>

      {/* OVERVIEW TAB */}
      {activeTab === 'overview' && (
        <div className="space-y-6">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-2">
              <span className="text-xs font-bold text-slate-400 uppercase">Registered Users</span>
              <h3 className="text-3xl font-black text-slate-900">{stats.totalUsers}</h3>
              <p className="text-[11px] text-blue-600 font-semibold">Active Accounts</p>
            </div>

            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-2">
              <span className="text-xs font-bold text-slate-400 uppercase">Total Cabs Fleet</span>
              <h3 className="text-3xl font-black text-slate-900">{stats.totalCabs}</h3>
              <p className="text-[11px] text-emerald-600 font-semibold">{stats.availableCabs} Cabs Available</p>
            </div>

            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-2">
              <span className="text-xs font-bold text-slate-400 uppercase">Total Rides Logged</span>
              <h3 className="text-3xl font-black text-slate-900">{stats.totalBookings}</h3>
              <p className="text-[11px] text-purple-600 font-semibold">{stats.completedRides} Completed</p>
            </div>

            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-2">
              <span className="text-xs font-bold text-slate-400 uppercase">System Revenue</span>
              <h3 className="text-3xl font-black text-emerald-600">₹{stats.totalRevenue.toFixed(2)}</h3>
              <p className="text-[11px] text-slate-500 font-medium">From Completed Rides</p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-4">
              <h3 className="font-bold text-slate-900 text-lg">Quick Actions</h3>
              <div className="grid grid-cols-2 gap-3">
                <button
                  onClick={() => setShowDriverModal(true)}
                  className="p-4 bg-slate-50 hover:bg-slate-100 rounded-2xl border border-slate-200 text-left font-bold text-slate-800 text-xs flex items-center justify-between transition-all"
                >
                  <span>+ Register New Driver</span>
                  <Plus className="w-4 h-4 text-purple-600" />
                </button>
                <button
                  onClick={() => setShowCabModal(true)}
                  className="p-4 bg-slate-50 hover:bg-slate-100 rounded-2xl border border-slate-200 text-left font-bold text-slate-800 text-xs flex items-center justify-between transition-all"
                >
                  <span>+ Add Cab to Fleet</span>
                  <Plus className="w-4 h-4 text-purple-600" />
                </button>
              </div>
            </div>

            <div className="bg-slate-900 text-white p-6 rounded-3xl border border-slate-800 shadow-xl space-y-3">
              <span className="text-xs font-mono font-bold text-purple-400">FASTAPI & ORM HEALTH</span>
              <h3 className="text-xl font-bold">Backend SQLite Connection Active</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Database schema synced via SQLAlchemy Session. Real-time updates automatically cascade across RESTful endpoints.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* USERS TAB */}
      {activeTab === 'users' && (
        <div className="bg-white rounded-3xl border border-slate-200 shadow-sm p-6 space-y-4">
          <h3 className="text-xl font-bold text-slate-900">User Directory ({usersList.length})</h3>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm text-slate-700">
              <thead className="bg-slate-50 text-xs font-bold text-slate-500 uppercase border-b border-slate-200">
                <tr>
                  <th className="p-3">ID</th>
                  <th className="p-3">Name</th>
                  <th className="p-3">Email</th>
                  <th className="p-3">Phone</th>
                  <th className="p-3">Role</th>
                  <th className="p-3">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {usersList.map(u => (
                  <tr key={u.id}>
                    <td className="p-3 font-mono font-bold">#{u.id}</td>
                    <td className="p-3 font-bold text-slate-900">{u.name}</td>
                    <td className="p-3">{u.email}</td>
                    <td className="p-3">{u.phone}</td>
                    <td className="p-3">
                      <span className={`px-2 py-0.5 text-[10px] font-bold uppercase rounded ${
                        u.role === 'admin' ? 'bg-purple-100 text-purple-800' : u.role === 'driver' ? 'bg-amber-100 text-amber-800' : 'bg-blue-100 text-blue-800'
                      }`}>
                        {u.role}
                      </span>
                    </td>
                    <td className="p-3">
                      {u.role !== 'admin' && (
                        <button
                          onClick={() => onDeleteUser(u.id)}
                          className="p-1.5 bg-rose-50 hover:bg-rose-100 text-rose-600 rounded-lg transition-all"
                          title="Delete User"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* DRIVERS TAB */}
      {activeTab === 'drivers' && (
        <div className="bg-white rounded-3xl border border-slate-200 shadow-sm p-6 space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="text-xl font-bold text-slate-900">Driver Roster ({driversList.length})</h3>
            <button
              onClick={() => setShowDriverModal(true)}
              className="px-4 py-2 bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs rounded-xl shadow-md transition-all flex items-center gap-1.5"
            >
              <Plus className="w-4 h-4" />
              <span>Add Driver</span>
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm text-slate-700">
              <thead className="bg-slate-50 text-xs font-bold text-slate-500 uppercase border-b border-slate-200">
                <tr>
                  <th className="p-3">Driver ID</th>
                  <th className="p-3">Name</th>
                  <th className="p-3">License Number</th>
                  <th className="p-3">Phone</th>
                  <th className="p-3">Status</th>
                  <th className="p-3">Rating</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {driversList.map(d => (
                  <tr key={d.id}>
                    <td className="p-3 font-mono font-bold">#{d.id}</td>
                    <td className="p-3 font-bold text-slate-900">{d.name}</td>
                    <td className="p-3 font-mono text-xs">{d.licenseNumber}</td>
                    <td className="p-3">{d.phone}</td>
                    <td className="p-3">
                      <span className={`px-2.5 py-1 rounded-full text-xs font-bold ${
                        d.status === 'Available' ? 'bg-emerald-100 text-emerald-800' : d.status === 'Busy' ? 'bg-amber-100 text-amber-800' : 'bg-slate-200 text-slate-700'
                      }`}>
                        {d.status}
                      </span>
                    </td>
                    <td className="p-3 font-bold text-amber-600">⭐ {d.rating || 5.0}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* CABS TAB */}
      {activeTab === 'cabs' && (
        <div className="bg-white rounded-3xl border border-slate-200 shadow-sm p-6 space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="text-xl font-bold text-slate-900">Fleet Cabs ({cabsList.length})</h3>
            <button
              onClick={() => setShowCabModal(true)}
              className="px-4 py-2 bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs rounded-xl shadow-md transition-all flex items-center gap-1.5"
            >
              <Plus className="w-4 h-4" />
              <span>Add Cab</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {cabsList.map(cab => (
              <div key={cab.id} className="p-5 rounded-2xl border border-slate-200 bg-slate-50/50 space-y-3">
                <div className="flex justify-between items-start">
                  <div>
                    <span className="text-xs font-mono font-bold text-slate-400">CAB #{cab.id}</span>
                    <h4 className="font-bold text-slate-900 text-base">{cab.cabType}</h4>
                    <span className="text-xs font-mono font-bold bg-white text-slate-800 border px-2 py-0.5 rounded mt-1 inline-block">
                      {cab.cabNumber}
                    </span>
                  </div>
                  <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                    cab.availability === 'Available' ? 'bg-emerald-100 text-emerald-800' : cab.availability === 'On Ride' ? 'bg-amber-100 text-amber-800' : 'bg-rose-100 text-rose-800'
                  }`}>
                    {cab.availability}
                  </span>
                </div>

                <div className="text-xs text-slate-600 space-y-1">
                  <p><strong>Assigned Driver:</strong> {cab.driverName || 'Unassigned'}</p>
                  <p><strong>Fare Rate:</strong> ₹{cab.fareRatePerKm}/km</p>
                </div>

                <div className="pt-2 border-t border-slate-200 flex gap-1">
                  <button
                    onClick={() => onUpdateCabAvailability(cab.id, 'Available')}
                    className="flex-1 py-1 text-[11px] font-bold bg-emerald-50 text-emerald-700 hover:bg-emerald-100 rounded transition-all"
                  >
                    Set Available
                  </button>
                  <button
                    onClick={() => onUpdateCabAvailability(cab.id, 'Maintenance')}
                    className="flex-1 py-1 text-[11px] font-bold bg-rose-50 text-rose-700 hover:bg-rose-100 rounded transition-all"
                  >
                    Maintenance
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* BOOKINGS TAB */}
      {activeTab === 'bookings' && (
        <div className="bg-white rounded-3xl border border-slate-200 shadow-sm p-6 space-y-4">
          <h3 className="text-xl font-bold text-slate-900">Global Bookings Master Log ({bookingsList.length})</h3>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm text-slate-700">
              <thead className="bg-slate-50 text-xs font-bold text-slate-500 uppercase border-b border-slate-200">
                <tr>
                  <th className="p-3">Booking ID</th>
                  <th className="p-3">Passenger</th>
                  <th className="p-3">Pickup → Drop</th>
                  <th className="p-3">Cab / Driver</th>
                  <th className="p-3">Fare</th>
                  <th className="p-3">Status</th>
                  <th className="p-3">Update Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {bookingsList.map(b => (
                  <tr key={b.id}>
                    <td className="p-3 text-xs font-mono font-bold">#{b.id}</td>
                    <td className="p-3 font-bold text-slate-900">{b.userName}</td>
                    <td className="p-3 text-xs max-w-xs truncate">{b.pickupLocation} → {b.destination}</td>
                    <td className="p-3 text-xs">{b.cabType} ({b.cabNumber}) / {b.driverName || 'N/A'}</td>
                    <td className="p-3 font-black text-emerald-600">₹{b.fare.toFixed(2)}</td>
                    <td className="p-3 font-bold text-xs">{b.bookingStatus}</td>
                    <td className="p-3">
                      <select
                        value={b.bookingStatus}
                        onChange={(e) => onUpdateBookingStatus(b.id, e.target.value as any)}
                        className="text-xs bg-slate-50 border border-slate-200 rounded-lg p-1 font-semibold"
                      >
                        <option value="Pending">Pending</option>
                        <option value="Accepted">Accepted</option>
                        <option value="In Progress">In Progress</option>
                        <option value="Completed">Completed</option>
                        <option value="Cancelled">Cancelled</option>
                      </select>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Add Driver Modal */}
      {showDriverModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-8 max-w-md w-full shadow-2xl space-y-4">
            <h3 className="text-xl font-bold text-slate-900">Register New Driver</h3>
            <form onSubmit={handleCreateDriver} className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-700">Driver Name</label>
                <input
                  type="text"
                  required
                  value={driverName}
                  onChange={(e) => setDriverName(e.target.value)}
                  className="w-full border rounded-xl p-2.5 text-sm"
                  placeholder="e.g. Marcus Vance"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700">License Number</label>
                <input
                  type="text"
                  required
                  value={driverLicense}
                  onChange={(e) => setDriverLicense(e.target.value)}
                  className="w-full border rounded-xl p-2.5 text-sm"
                  placeholder="e.g. DL-88192-CA"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700">Phone</label>
                <input
                  type="text"
                  value={driverPhone}
                  onChange={(e) => setDriverPhone(e.target.value)}
                  className="w-full border rounded-xl p-2.5 text-sm"
                  placeholder="+1-555-0199"
                />
              </div>
              <div className="flex gap-2 pt-2">
                <button type="submit" className="flex-1 py-3 bg-purple-600 text-white font-bold rounded-xl">Save Driver</button>
                <button type="button" onClick={() => setShowDriverModal(false)} className="px-4 bg-slate-200 text-slate-700 font-bold rounded-xl">Cancel</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add Cab Modal */}
      {showCabModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-8 max-w-md w-full shadow-2xl space-y-4">
            <h3 className="text-xl font-bold text-slate-900">Add New Fleet Cab</h3>
            <form onSubmit={handleCreateCab} className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-700">Cab Registration Number</label>
                <input
                  type="text"
                  required
                  value={cabNumber}
                  onChange={(e) => setCabNumber(e.target.value)}
                  className="w-full border rounded-xl p-2.5 text-sm"
                  placeholder="e.g. NY-9988"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700">Vehicle Type</label>
                <select
                  value={cabType}
                  onChange={(e) => setCabType(e.target.value as any)}
                  className="w-full border rounded-xl p-2.5 text-sm"
                >
                  <option value="Sedan">Sedan (₹18.00/km)</option>
                  <option value="SUV">SUV (₹25.00/km)</option>
                  <option value="Luxury">Luxury (₹45.00/km)</option>
                  <option value="EV">EV (₹20.00/km)</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700">Assign Driver (Optional)</label>
                <select
                  value={assignedDriverId}
                  onChange={(e) => setAssignedDriverId(e.target.value)}
                  className="w-full border rounded-xl p-2.5 text-sm"
                >
                  <option value="">-- No Driver Assigned --</option>
                  {driversList.map(d => (
                    <option key={d.id} value={d.id}>{d.name} ({d.licenseNumber})</option>
                  ))}
                </select>
              </div>
              <div className="flex gap-2 pt-2">
                <button type="submit" className="flex-1 py-3 bg-purple-600 text-white font-bold rounded-xl">Create Cab</button>
                <button type="button" onClick={() => setShowCabModal(false)} className="px-4 bg-slate-200 text-slate-700 font-bold rounded-xl">Cancel</button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
