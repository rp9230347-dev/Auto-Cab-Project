import React from 'react';
import { User, Role } from '../types';
import { Car, Shield, UserCheck, Code, LogIn, LogOut, LayoutDashboard, Calendar, Home } from 'lucide-react';

interface NavbarProps {
  currentUser: User | null;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onOpenAuth: () => void;
  onLogout: () => void;
  onOpenCodeViewer: () => void;
  onQuickRoleSwitch: (role: Role) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentUser,
  activeTab,
  setActiveTab,
  onOpenAuth,
  onLogout,
  onOpenCodeViewer,
  onQuickRoleSwitch
}) => {
  return (
    <header className="sticky top-0 z-40 bg-slate-900 border-b border-slate-800 text-white shadow-lg">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          
          {/* Logo */}
          <div className="flex items-center space-x-3 cursor-pointer" onClick={() => setActiveTab('home')}>
            <div className="p-2 bg-blue-600 rounded-xl text-white shadow-md shadow-blue-500/20">
              <Car className="w-6 h-6" />
            </div>
            <div>
              <span className="text-xl font-black tracking-tight text-white flex items-center gap-1.5">
                AutoCab <span className="text-xs px-2 py-0.5 rounded-full bg-blue-500/20 text-blue-400 font-bold border border-blue-500/30">SYSTEM</span>
              </span>
              <p className="text-[10px] text-slate-400 -mt-0.5 font-medium">Smart Fleet & Ride Booking</p>
            </div>
          </div>

            {/* Navigation Links */}
            <nav className="hidden md:flex items-center space-x-1">
              <button
                onClick={() => setActiveTab('home')}
                className={`flex items-center space-x-2 px-3.5 py-2 rounded-lg text-sm font-semibold transition-colors ${
                  activeTab === 'home' ? 'bg-blue-600 text-white' : 'text-slate-300 hover:text-white hover:bg-slate-800'
                }`}
              >
                <Home className="w-4 h-4" />
                <span>Home</span>
              </button>

              <button
                onClick={() => setActiveTab('booking')}
                className={`flex items-center space-x-2 px-3.5 py-2 rounded-lg text-sm font-semibold transition-colors ${
                  activeTab === 'booking' ? 'bg-blue-600 text-white' : 'text-slate-300 hover:text-white hover:bg-slate-800'
                }`}
              >
                <Calendar className="w-4 h-4" />
                <span>Book Cab</span>
              </button>

              {/* Role Specific Dashboard Navigation */}
              <button
                onClick={() => {
                  if (currentUser?.role === 'admin') setActiveTab('admin-dashboard');
                  else if (currentUser?.role === 'driver') setActiveTab('driver-dashboard');
                  else setActiveTab('user-dashboard');
                }}
                className={`flex items-center space-x-2 px-3.5 py-2 rounded-lg text-sm font-semibold transition-colors ${
                  activeTab.includes('dashboard') ? 'bg-blue-600 text-white' : 'text-slate-300 hover:text-white hover:bg-slate-800'
                }`}
              >
                <LayoutDashboard className="w-4 h-4" />
                <span>
                  {currentUser?.role === 'admin' ? 'Admin Portal' : currentUser?.role === 'driver' ? 'Driver Portal' : 'My Dashboard'}
                </span>
              </button>

              <button
                onClick={onOpenCodeViewer}
                className="flex items-center space-x-2 px-3.5 py-2 rounded-lg text-sm font-semibold text-emerald-400 hover:text-emerald-300 bg-emerald-950/40 border border-emerald-500/30 hover:bg-emerald-900/50 transition-all"
              >
                <Code className="w-4 h-4" />
                <span>View Backend Code</span>
              </button>
            </nav>

            {/* User Controls & Account Login */}
            <div className="flex items-center space-x-3">
              
              {/* Login / Switch Account Button */}
              {currentUser ? (
                <div className="flex items-center space-x-3">
                  <div className="text-right hidden sm:block">
                    <p className="text-sm font-bold text-white leading-tight">{currentUser.name}</p>
                    <span className={`inline-block text-[10px] uppercase font-bold px-1.5 py-0.2 rounded ${
                      currentUser.role === 'admin' ? 'bg-purple-500/20 text-purple-300 border border-purple-500/30' :
                      currentUser.role === 'driver' ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30' :
                      'bg-blue-500/20 text-blue-300 border border-blue-500/30'
                    }`}>
                      {currentUser.role}
                    </span>
                  </div>
                  <button
                    onClick={onOpenAuth}
                    className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs text-slate-300 hover:text-white border border-slate-700 font-semibold transition-all"
                    title="Switch Account"
                  >
                    Switch Account
                  </button>
                  <button
                    onClick={onLogout}
                    title="Sign Out"
                    className="p-2 rounded-lg bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700 transition-colors"
                  >
                    <LogOut className="w-5 h-5" />
                  </button>
                </div>
              ) : (
                <button
                  onClick={onOpenAuth}
                  className="flex items-center space-x-2 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-sm font-bold shadow-lg shadow-blue-600/25 transition-all"
                >
                  <LogIn className="w-4 h-4" />
                  <span>Login / Register</span>
                </button>
              )}

            </div>

        </div>
      </div>
    </header>
  );
};
