import React, { useState } from 'react';
import { User, Driver, Booking } from '../types';
import { Car, Power, CheckCircle, Navigation, Clock, DollarSign, AlertCircle, Phone } from 'lucide-react';

interface DriverDashboardProps {
  currentUser: User;
  driverInfo: Driver | undefined;
  bookings: Booking[];
  onUpdateDriverStatus: (driverId: number, status: Driver['status']) => Promise<void>;
  onUpdateBookingStatus: (bookingId: number, status: Booking['bookingStatus']) => Promise<void>;
}

export const DriverDashboard: React.FC<DriverDashboardProps> = ({
  currentUser,
  driverInfo,
  bookings,
  onUpdateDriverStatus,
  onUpdateBookingStatus
}) => {
  const [loading, setLoading] = useState(false);

  // Driver rides
  const pendingRequests = bookings.filter(b => b.bookingStatus === 'Pending');
  const myActiveRides = bookings.filter(b => b.bookingStatus === 'Accepted' || b.bookingStatus === 'In Progress');
  const completedRides = bookings.filter(b => b.bookingStatus === 'Completed');

  const totalEarnings = completedRides.reduce((sum, b) => sum + b.fare, 0);

  const handleToggleStatus = async (newStatus: Driver['status']) => {
    if (!driverInfo) return;
    try {
      setLoading(true);
      await onUpdateDriverStatus(driverInfo.id, newStatus);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-8 pb-12">
      
      {/* Driver Header */}
      <div className="bg-slate-900 text-white rounded-3xl p-8 border border-slate-800 shadow-xl flex flex-col lg:flex-row justify-between items-start lg:items-center gap-6">
        <div>
          <div className="flex items-center gap-3">
            <h1 className="text-3xl font-black tracking-tight">{currentUser.name}'s Driver Portal</h1>
            <span className="bg-amber-500/20 text-amber-300 text-xs font-bold px-2.5 py-0.5 rounded-full border border-amber-500/30 uppercase">Cab Driver</span>
          </div>
          <p className="text-slate-400 text-sm mt-1">
            License No: <span className="text-slate-200 font-mono font-bold">{driverInfo?.licenseNumber || 'DL-98234-NY'}</span> | Phone: {currentUser.phone}
          </p>
        </div>

        {/* Online / Offline Status Toggle */}
        <div className="flex items-center space-x-3 bg-slate-800 p-2 rounded-2xl border border-slate-700">
          <span className="text-xs font-bold text-slate-400 px-2 uppercase">Status:</span>
          {(['Available', 'Busy', 'Offline'] as const).map(st => (
            <button
              key={st}
              disabled={loading}
              onClick={() => handleToggleStatus(st)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                driverInfo?.status === st
                  ? st === 'Available' ? 'bg-emerald-600 text-white shadow-md' : st === 'Busy' ? 'bg-amber-600 text-white shadow-md' : 'bg-slate-600 text-white'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {st}
            </button>
          ))}
        </div>
      </div>

      {/* Driver Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex items-center space-x-4">
          <div className="w-12 h-12 bg-emerald-100 text-emerald-600 rounded-2xl flex items-center justify-center font-bold">
            <DollarSign className="w-6 h-6" />
          </div>
          <div>
            <span className="text-xs text-slate-500 font-bold uppercase">Total Shift Earnings</span>
            <h3 className="text-2xl font-black text-slate-900">₹{totalEarnings.toFixed(2)}</h3>
          </div>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex items-center space-x-4">
          <div className="w-12 h-12 bg-blue-100 text-blue-600 rounded-2xl flex items-center justify-center font-bold">
            <CheckCircle className="w-6 h-6" />
          </div>
          <div>
            <span className="text-xs text-slate-500 font-bold uppercase">Completed Trips</span>
            <h3 className="text-2xl font-black text-slate-900">{completedRides.length}</h3>
          </div>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex items-center space-x-4">
          <div className="w-12 h-12 bg-purple-100 text-purple-600 rounded-2xl flex items-center justify-center font-bold">
            <Car className="w-6 h-6" />
          </div>
          <div>
            <span className="text-xs text-slate-500 font-bold uppercase">Driver Rating</span>
            <h3 className="text-2xl font-black text-slate-900">⭐ 4.9 / 5.0</h3>
          </div>
        </div>
      </div>

      {/* Active Trip Management */}
      <div className="space-y-4">
        <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2">
          <Navigation className="w-5 h-5 text-blue-600" />
          <span>Active Assigned Trip ({myActiveRides.length})</span>
        </h2>

        {myActiveRides.length === 0 ? (
          <div className="bg-white p-6 rounded-2xl border border-slate-200 text-center space-y-2">
            <Clock className="w-8 h-8 text-slate-400 mx-auto" />
            <p className="text-slate-700 font-bold text-sm">No trip currently in progress.</p>
            <p className="text-xs text-slate-500">Check incoming dispatch requests below to accept your next ride.</p>
          </div>
        ) : (
          myActiveRides.map(ride => (
            <div key={ride.id} className="bg-slate-900 text-white p-6 rounded-3xl border border-slate-800 shadow-xl space-y-4">
              <div className="flex justify-between items-center border-b border-slate-800 pb-3">
                <div>
                  <span className="text-xs font-mono font-bold text-blue-400">TRIP #{ride.id}</span>
                  <h3 className="text-xl font-bold text-white">{ride.userName} ({ride.userPhone || '+1-555-0123'})</h3>
                </div>
                <span className="px-3 py-1 rounded-full text-xs font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                  {ride.bookingStatus}
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="text-xs font-bold text-slate-400 uppercase block">Pickup Location</span>
                  <p className="text-white font-medium text-base mt-0.5">{ride.pickupLocation}</p>
                </div>

                <div>
                  <span className="text-xs font-bold text-slate-400 uppercase block">Destination</span>
                  <p className="text-white font-medium text-base mt-0.5">{ride.destination}</p>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-800 flex items-center justify-between">
                <div>
                  <span className="text-xs text-slate-400 block">Trip Fare</span>
                  <span className="text-2xl font-black text-emerald-400">₹{ride.fare.toFixed(2)}</span>
                </div>

                <div className="flex gap-2">
                  {ride.bookingStatus === 'Accepted' && (
                    <button
                      onClick={() => onUpdateBookingStatus(ride.id, 'In Progress')}
                      className="px-5 py-2.5 bg-blue-600 hover:bg-blue-500 text-white font-bold text-sm rounded-xl transition-all"
                    >
                      Start Trip
                    </button>
                  )}

                  {ride.bookingStatus === 'In Progress' && (
                    <button
                      onClick={() => onUpdateBookingStatus(ride.id, 'Completed')}
                      className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-sm rounded-xl transition-all"
                    >
                      Complete Ride & Collect Fare
                    </button>
                  )}
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Incoming Booking Dispatch Requests */}
      <div className="bg-white rounded-3xl border border-slate-200 p-6 space-y-4 shadow-sm">
        <h2 className="text-xl font-bold text-slate-900">Incoming Ride Requests ({pendingRequests.length})</h2>

        {pendingRequests.length === 0 ? (
          <p className="text-xs text-slate-500 py-4 text-center">No pending ride requests in dispatch queue.</p>
        ) : (
          <div className="space-y-3">
            {pendingRequests.map(b => (
              <div key={b.id} className="p-4 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-between">
                <div>
                  <span className="text-xs font-mono font-bold text-slate-400">BOOKING #{b.id}</span>
                  <h4 className="font-bold text-slate-900 text-base">{b.userName}</h4>
                  <p className="text-xs text-slate-600 mt-0.5">
                    <strong>Pickup:</strong> {b.pickupLocation} → <strong>Drop:</strong> {b.destination}
                  </p>
                </div>

                <div className="flex items-center gap-4">
                  <span className="text-lg font-black text-emerald-600">₹{b.fare.toFixed(2)}</span>
                  <button
                    onClick={() => onUpdateBookingStatus(b.id, 'Accepted')}
                    className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs rounded-xl shadow-md transition-all"
                  >
                    Accept Ride
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

    </div>
  );
};
