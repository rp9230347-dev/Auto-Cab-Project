import { User, Driver, Cab, Booking, SystemStats } from '../types.js';

// Pre-seeded Initial Database Records
export let users: User[] = [
  { id: 1, name: 'Alex Rivera', email: 'admin@autocab.com', phone: '+1-555-0100', role: 'admin', createdAt: '2026-01-10T08:00:00Z' },
  { id: 2, name: 'John Smith', email: 'john.driver@autocab.com', phone: '+1-555-0199', role: 'driver', createdAt: '2026-02-15T10:30:00Z' },
  { id: 3, name: 'Sarah Jenkins', email: 'sarah.driver@autocab.com', phone: '+1-555-0188', role: 'driver', createdAt: '2026-03-01T12:00:00Z' },
  { id: 4, name: 'Emily Chen', email: 'user@autocab.com', phone: '+1-555-0123', role: 'user', createdAt: '2026-04-12T14:15:00Z' },
  { id: 5, name: 'David Miller', email: 'david@autocab.com', phone: '+1-555-0144', role: 'user', createdAt: '2026-05-20T09:45:00Z' }
];

// Hash map for passwords (in plaintext/bcrypt for demo compatibility)
export const userPasswords: Record<string, string> = {
  'admin@autocab.com': 'admin123',
  'john.driver@autocab.com': 'driver123',
  'sarah.driver@autocab.com': 'driver123',
  'user@autocab.com': 'user123',
  'david@autocab.com': 'user123'
};

export let drivers: Driver[] = [
  { id: 1, name: 'John Smith', phone: '+1-555-0199', licenseNumber: 'DL-98234-NY', status: 'Available', rating: 4.9, totalRides: 142 },
  { id: 2, name: 'Sarah Jenkins', phone: '+1-555-0188', licenseNumber: 'DL-76123-CA', status: 'Busy', rating: 4.8, totalRides: 98 },
  { id: 3, name: 'Michael Chang', phone: '+1-555-0177', licenseNumber: 'DL-54321-TX', status: 'Available', rating: 4.95, totalRides: 210 },
  { id: 4, name: 'Elena Rostova', phone: '+1-555-0166', licenseNumber: 'DL-33445-FL', status: 'Offline', rating: 4.7, totalRides: 64 }
];

export let cabs: Cab[] = [
  { id: 1, driverId: 1, cabNumber: 'NY-7721', cabType: 'Sedan', availability: 'Available', fareRatePerKm: 18.00 },
  { id: 2, driverId: 2, cabNumber: 'CA-8832', cabType: 'SUV', availability: 'On Ride', fareRatePerKm: 25.00 },
  { id: 3, driverId: 3, cabNumber: 'TX-4410', cabType: 'Luxury', availability: 'Available', fareRatePerKm: 45.00 },
  { id: 4, driverId: 4, cabNumber: 'FL-9901', cabType: 'EV', availability: 'Maintenance', fareRatePerKm: 20.00 }
];

export let bookings: Booking[] = [
  {
    id: 101,
    userId: 4,
    userName: 'Emily Chen',
    userPhone: '+1-555-0123',
    cabId: 1,
    cabNumber: 'NY-7721',
    cabType: 'Sedan',
    driverName: 'John Smith',
    pickupLocation: 'Downtown Central Station',
    destination: 'Airport Terminal 2',
    fare: 357.60,
    distanceKm: 18.2,
    bookingStatus: 'Completed',
    bookingDate: '2026-08-06 14:30:00'
  },
  {
    id: 102,
    userId: 4,
    userName: 'Emily Chen',
    userPhone: '+1-555-0123',
    cabId: 2,
    cabNumber: 'CA-8832',
    cabType: 'SUV',
    driverName: 'Sarah Jenkins',
    pickupLocation: 'Financial District',
    destination: 'Tech Park Plaza',
    fare: 215.00,
    distanceKm: 7.4,
    bookingStatus: 'In Progress',
    bookingDate: '2026-08-07 08:15:00'
  },
  {
    id: 103,
    userId: 5,
    userName: 'David Miller',
    userPhone: '+1-555-0144',
    cabId: 3,
    cabNumber: 'TX-4410',
    cabType: 'Luxury',
    driverName: 'Michael Chang',
    pickupLocation: 'North Suburbs',
    destination: 'City Shopping Mall',
    fare: 322.50,
    distanceKm: 6.5,
    bookingStatus: 'Pending',
    bookingDate: '2026-08-07 09:00:00'
  }
];

// Helper to compute system statistics
export function getSystemStats(): SystemStats {
  const completed = bookings.filter(b => b.bookingStatus === 'Completed');
  const revenue = completed.reduce((sum, b) => sum + b.fare, 0);
  const available = cabs.filter(c => c.availability === 'Available').length;

  return {
    totalUsers: users.length,
    totalDrivers: drivers.length,
    totalCabs: cabs.length,
    availableCabs: available,
    totalBookings: bookings.length,
    completedRides: completed.length,
    totalRevenue: parseFloat(revenue.toFixed(2))
  };
}
