# AutoCab System - Full-Stack Cab Booking & Fleet Management Platform

AutoCab System is a full-stack web application designed for seamless cab booking, driver dispatching, and fleet administration.

## 📁 Project Structure

```
AutoCab-System/
├── frontend/
│   ├── index.html       # Home Page & Fleet Showcase
│   ├── login.html       # User / Driver / Admin Login Page
│   ├── register.html    # Account Registration Page
│   ├── booking.html     # Interactive Cab Booking Engine
│   ├── dashboard.html   # User & Driver & Admin Unified Dashboards
│   ├── style.css        # Responsive CSS Utility Styling
│   └── script.js        # API Client & DOM Interactivity
└── backend/
    ├── main.py          # FastAPI Main Entry point & CORS
    ├── database.py      # SQLAlchemy Engine & SQLite Connection
    ├── models.py        # Database ORM Tables (Users, Drivers, Cabs, Bookings)
    ├── schemas.py       # Pydantic Schemas for Validation
    ├── crud.py          # Database Access & Query Operations
    ├── auth.py          # JWT Generation & Password Hashing
    └── requirements.txt # Python Dependencies
```

---

## 🗄️ Database Tables (SQLite / PostgreSQL)

1. **Users**: `id`, `name`, `email`, `phone`, `password`, `role` (`user`, `driver`, `admin`)
2. **Drivers**: `id`, `name`, `phone`, `license_number`, `status` (`Available`, `Busy`, `Offline`)
3. **Cabs**: `id`, `driver_id`, `cab_number`, `cab_type`, `availability` (`Available`, `On Ride`, `Maintenance`)
4. **Bookings**: `id`, `user_id`, `cab_id`, `pickup_location`, `destination`, `fare`, `booking_status`, `booking_date`

---

## 🚀 How to Run Locally

### 1. Backend Setup (FastAPI & SQLite)

1. Navigate to the backend directory:
   ```bash
   cd backend
   ```
2. Create and activate a Python virtual environment:
   ```bash
   python3 -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```
3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
4. Start the FastAPI Uvicorn Server:
   ```bash
   uvicorn main:app --reload --host 0.0.0.0 --port 8000
   ```
5. Access interactive API Documentation (Swagger UI):
   `http://localhost:8000/docs`

---

### 2. Frontend Setup

1. Simply serve the `frontend/` folder using any static HTTP server (e.g., Live Server extension in VS Code or Python HTTP server):
   ```bash
   cd frontend
   python3 -m http.server 3000
   ```
2. Open `http://localhost:3000` in your web browser.

---

## 🔑 Default Test Accounts

| Role | Email | Password |
|------|-------|----------|
| **Admin** | `admin@autocab.com` | `admin123` |
| **Driver** | `john.driver@autocab.com` | `driver123` |
| **Passenger** | `user@autocab.com` | `user123` |
