// AutoCab System Frontend JavaScript Engine
const API_BASE_URL = 'http://localhost:8000/api';

// Helper: Get Auth Token
function getToken() {
  return localStorage.getItem('autocab_token');
}

// Helper: Get Logged In User
function getUser() {
  const userStr = localStorage.getItem('autocab_user');
  return userStr ? JSON.parse(userStr) : null;
}

// Handle User Registration
async function handleRegister(event) {
  event.preventDefault();
  const name = document.getElementById('reg-name').value;
  const email = document.getElementById('reg-email').value;
  const phone = document.getElementById('reg-phone').value;
  const password = document.getElementById('reg-password').value;
  const role = document.getElementById('reg-role').value;

  try {
    const res = await fetch(`${API_BASE_URL}/auth/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, email, phone, password, role })
    });
    const data = await res.json();
    if (res.ok) {
      alert('Registration successful! Please login.');
      window.location.href = 'login.html';
    } else {
      alert(data.detail || 'Registration failed');
    }
  } catch (err) {
    console.error(err);
    alert('Server connection error.');
  }
}

// Handle User Login
async function handleLogin(event) {
  event.preventDefault();
  const email = document.getElementById('login-email').value;
  const password = document.getElementById('login-password').value;

  try {
    const res = await fetch(`${API_BASE_URL}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password })
    });
    const data = await res.json();
    if (res.ok) {
      localStorage.setItem('autocab_token', data.access_token);
      localStorage.setItem('autocab_user', JSON.stringify(data.user));
      alert(`Welcome back, ${data.user.name}!`);
      window.location.href = 'dashboard.html';
    } else {
      alert(data.detail || 'Invalid login credentials');
    }
  } catch (err) {
    console.error(err);
    alert('Server connection error.');
  }
}

// Logout
function logout() {
  localStorage.removeItem('autocab_token');
  localStorage.removeItem('autocab_user');
  window.location.href = 'login.html';
}

// Fetch and display available cabs for booking
async function loadAvailableCabs() {
  const cabType = document.getElementById('cab-type-filter')?.value || '';
  const container = document.getElementById('cabs-container');
  if (!container) return;

  try {
    const res = await fetch(`${API_BASE_URL}/cabs/available?cab_type=${cabType}`);
    const cabs = await res.json();
    container.innerHTML = cabs.map(cab => `
      <div class="card">
        <h3>${cab.cab_type} Cab</h3>
        <p><strong>Cab Number:</strong> ${cab.cab_number}</p>
        <p><strong>Status:</strong> <span class="badge badge-success">${cab.availability}</span></p>
        <button class="btn" style="margin-top: 1rem;" onclick="selectCabForBooking(${cab.id}, '${cab.cab_type}')">Book This Cab</button>
      </div>
    `).join('');
  } catch (err) {
    container.innerHTML = '<p>Error loading cabs. Ensure backend server is running.</p>';
  }
}

// Book a Cab
async function handleBooking(event) {
  event.preventDefault();
  const cabId = document.getElementById('selected-cab-id').value;
  const pickup = document.getElementById('pickup-location').value;
  const destination = document.getElementById('destination').value;
  const fare = parseFloat(document.getElementById('calculated-fare').value);

  const token = getToken();
  if (!token) {
    alert('Please login first to book a cab.');
    window.location.href = 'login.html';
    return;
  }

  try {
    const res = await fetch(`${API_BASE_URL}/bookings`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({
        cab_id: parseInt(cabId),
        pickup_location: pickup,
        destination: destination,
        fare: fare
      })
    });
    if (res.ok) {
      alert('Cab booked successfully!');
      window.location.href = 'dashboard.html';
    } else {
      const err = await res.json();
      alert(err.detail || 'Booking failed');
    }
  } catch (err) {
    alert('Error connecting to backend.');
  }
}
