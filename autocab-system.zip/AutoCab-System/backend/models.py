from sqlalchemy import Column, Integer, String, Float, ForeignKey, DateTime
from sqlalchemy.orm import relationship
from datetime import datetime
from database import Base

class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False)
    email = Column(String, unique=True, index=True, nullable=False)
    phone = Column(String, nullable=False)
    password = Column(String, nullable=False)
    role = Column(String, default="user")  # 'user', 'driver', 'admin'

    bookings = relationship("Booking", back_populates="user")


class Driver(Base):
    __tablename__ = "drivers"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False)
    phone = Column(String, nullable=False)
    license_number = Column(String, unique=True, nullable=False)
    status = Column(String, default="Available")  # 'Available', 'Busy', 'Offline'

    cabs = relationship("Cab", back_populates="driver")


class Cab(Base):
    __tablename__ = "cabs"

    id = Column(Integer, primary_key=True, index=True)
    driver_id = Column(Integer, ForeignKey("drivers.id"), nullable=True)
    cab_number = Column(String, unique=True, nullable=False)
    cab_type = Column(String, nullable=False)  # 'Sedan', 'SUV', 'Luxury', 'EV'
    availability = Column(String, default="Available")  # 'Available', 'On Ride', 'Maintenance'

    driver = relationship("Driver", back_populates="cabs")
    bookings = relationship("Booking", back_populates="cab")


class Booking(Base):
    __tablename__ = "bookings"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    cab_id = Column(Integer, ForeignKey("cabs.id"), nullable=False)
    pickup_location = Column(String, nullable=False)
    destination = Column(String, nullable=False)
    fare = Column(Float, nullable=False)
    booking_status = Column(String, default="Pending")  # 'Pending', 'Accepted', 'In Progress', 'Completed', 'Cancelled'
    booking_date = Column(DateTime, default=datetime.utcnow)

    user = relationship("User", back_populates="bookings")
    cab = relationship("Cab", back_populates="bookings")
