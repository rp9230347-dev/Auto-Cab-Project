from pydantic import BaseModel, EmailStr
from typing import Optional, List
from datetime import datetime

# User Schemas
class UserBase(BaseModel):
    name: str
    email: EmailStr
    phone: str
    role: Optional[str] = "user"

class UserCreate(UserBase):
    password: str

class UserResponse(UserBase):
    id: int

    class Config:
        from_attributes = True

# Auth Schemas
class Token(BaseModel):
    access_token: str
    token_type: str
    user: UserResponse

class LoginRequest(BaseModel):
    email: EmailStr
    password: str

# Driver Schemas
class DriverBase(BaseModel):
    name: str
    phone: str
    license_number: str
    status: Optional[str] = "Available"

class DriverCreate(DriverBase):
    pass

class DriverResponse(DriverBase):
    id: int

    class Config:
        from_attributes = True

# Cab Schemas
class CabBase(BaseModel):
    driver_id: Optional[int] = None
    cab_number: str
    cab_type: str
    availability: Optional[str] = "Available"

class CabCreate(CabBase):
    pass

class CabResponse(CabBase):
    id: int
    driver: Optional[DriverResponse] = None

    class Config:
        from_attributes = True

# Booking Schemas
class BookingBase(BaseModel):
    cab_id: int
    pickup_location: str
    destination: str
    fare: float

class BookingCreate(BookingBase):
    user_id: Optional[int] = None

class BookingStatusUpdate(BaseModel):
    booking_status: str

class BookingResponse(BookingBase):
    id: int
    user_id: int
    booking_status: str
    booking_date: datetime
    user: Optional[UserResponse] = None
    cab: Optional[CabResponse] = None

    class Config:
        from_attributes = True
