from sqlalchemy.orm import Session
import models, schemas, auth

# User CRUD
def get_user_by_email(db: Session, email: str):
    return db.query(models.User).filter(models.User.email == email).first()

def create_user(db: Session, user: schemas.UserCreate):
    hashed_password = auth.get_password_hash(user.password)
    db_user = models.User(
        name=user.name,
        email=user.email,
        phone=user.phone,
        password=hashed_password,
        role=user.role or "user"
    )
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    return db_user

def get_users(db: Session, skip: int = 0, limit: int = 100):
    return db.query(models.User).offset(skip).limit(limit).all()

def delete_user(db: Session, user_id: int):
    user = db.query(models.User).filter(models.User.id == user_id).first()
    if user:
        db.delete(user)
        db.commit()
        return True
    return False

# Driver CRUD
def get_drivers(db: Session, skip: int = 0, limit: int = 100):
    return db.query(models.Driver).offset(skip).limit(limit).all()

def create_driver(db: Session, driver: schemas.DriverCreate):
    db_driver = models.Driver(**driver.model_dump())
    db.add(db_driver)
    db.commit()
    db.refresh(db_driver)
    return db_driver

def update_driver_status(db: Session, driver_id: int, status: str):
    driver = db.query(models.Driver).filter(models.Driver.id == driver_id).first()
    if driver:
        driver.status = status
        db.commit()
        db.refresh(driver)
    return driver

# Cab CRUD
def get_cabs(db: Session, skip: int = 0, limit: int = 100):
    return db.query(models.Cab).offset(skip).limit(limit).all()

def create_cab(db: Session, cab: schemas.CabCreate):
    db_cab = models.Cab(**cab.model_dump())
    db.add(db_cab)
    db.commit()
    db.refresh(db_cab)
    return db_cab

def get_available_cabs(db: Session, cab_type: str = None):
    query = db.query(models.Cab).filter(models.Cab.availability == "Available")
    if cab_type and cab_type != "All":
        query = query.filter(models.Cab.cab_type == cab_type)
    return query.all()

# Booking CRUD
def create_booking(db: Session, booking: schemas.BookingCreate, user_id: int):
    db_booking = models.Booking(
        user_id=user_id,
        cab_id=booking.cab_id,
        pickup_location=booking.pickup_location,
        destination=booking.destination,
        fare=booking.fare,
        booking_status="Pending"
    )
    db.add(db_booking)
    
    # Mark Cab as 'On Ride'
    cab = db.query(models.Cab).filter(models.Cab.id == booking.cab_id).first()
    if cab:
        cab.availability = "On Ride"

    db.commit()
    db.refresh(db_booking)
    return db_booking

def get_user_bookings(db: Session, user_id: int):
    return db.query(models.Booking).filter(models.Booking.user_id == user_id).order_by(models.Booking.booking_date.desc()).all()

def get_all_bookings(db: Session):
    return db.query(models.Booking).order_by(models.Booking.booking_date.desc()).all()

def update_booking_status(db: Session, booking_id: int, status: str):
    booking = db.query(models.Booking).filter(models.Booking.id == booking_id).first()
    if booking:
        booking.booking_status = status
        if status in ["Completed", "Cancelled"]:
            cab = db.query(models.Cab).filter(models.Cab.id == booking.cab_id).first()
            if cab:
                cab.availability = "Available"
        db.commit()
        db.refresh(booking)
    return booking
