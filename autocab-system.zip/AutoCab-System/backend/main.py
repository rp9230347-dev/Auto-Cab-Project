from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from typing import List, Optional
import models, schemas, crud, auth, database

# Create tables in SQLite
models.Base.metadata.create_all(bind=database.engine)

app = FastAPI(
    title="AutoCab System API",
    description="Backend RESTful API services for Cab Booking and Fleet Management System",
    version="1.0.0"
)

# CORS Middleware Configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
def read_root():
    return {"status": "online", "message": "AutoCab System API is up and running"}

# --- AUTHENTICATION ROUTES ---
@app.post("/api/auth/register", response_model=schemas.UserResponse)
def register_user(user: schemas.UserCreate, db: Session = Depends(database.get_db)):
    db_user = crud.get_user_by_email(db, email=user.email)
    if db_user:
        raise HTTPException(status_code=400, detail="Email address is already registered.")
    return crud.create_user(db=db, user=user)

@app.post("/api/auth/login", response_model=schemas.Token)
def login_for_access_token(login_data: schemas.LoginRequest, db: Session = Depends(database.get_db)):
    user = crud.get_user_by_email(db, email=login_data.email)
    if not user or not auth.verify_password(login_data.password, user.password):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect email or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    access_token = auth.create_access_token(data={"sub": user.email})
    return {
        "access_token": access_token,
        "token_type": "bearer",
        "user": user
    }

@app.get("/api/auth/me", response_model=schemas.UserResponse)
def get_current_user_profile(current_user: models.User = Depends(auth.get_current_user)):
    return current_user

# --- USER ROUTES ---
@app.get("/api/users", response_model=List[schemas.UserResponse])
def read_users(db: Session = Depends(database.get_db), current_user: models.User = Depends(auth.require_admin)):
    return crud.get_users(db)

@app.delete("/api/users/{user_id}")
def delete_user_route(user_id: int, db: Session = Depends(database.get_db), current_user: models.User = Depends(auth.require_admin)):
    success = crud.delete_user(db, user_id)
    if not success:
        raise HTTPException(status_code=404, detail="User not found")
    return {"message": "User deleted successfully"}

# --- DRIVER ROUTES ---
@app.get("/api/drivers", response_model=List[schemas.DriverResponse])
def read_drivers(db: Session = Depends(database.get_db)):
    return crud.get_drivers(db)

@app.post("/api/drivers", response_model=schemas.DriverResponse)
def create_new_driver(driver: schemas.DriverCreate, db: Session = Depends(database.get_db), current_user: models.User = Depends(auth.require_admin)):
    return crud.create_driver(db, driver)

@app.put("/api/drivers/{driver_id}/status", response_model=schemas.DriverResponse)
def update_driver_status_route(driver_id: int, status: str, db: Session = Depends(database.get_db)):
    updated_driver = crud.update_driver_status(db, driver_id, status)
    if not updated_driver:
        raise HTTPException(status_code=404, detail="Driver not found")
    return updated_driver

# --- CAB ROUTES ---
@app.get("/api/cabs", response_model=List[schemas.CabResponse])
def read_cabs(db: Session = Depends(database.get_db)):
    return crud.get_cabs(db)

@app.get("/api/cabs/available", response_model=List[schemas.CabResponse])
def read_available_cabs(cab_type: Optional[str] = None, db: Session = Depends(database.get_db)):
    return crud.get_available_cabs(db, cab_type=cab_type)

@app.post("/api/cabs", response_model=schemas.CabResponse)
def create_new_cab(cab: schemas.CabCreate, db: Session = Depends(database.get_db), current_user: models.User = Depends(auth.require_admin)):
    return crud.create_cab(db, cab)

# --- BOOKING ROUTES ---
@app.post("/api/bookings", response_model=schemas.BookingResponse)
def create_booking_route(booking: schemas.BookingCreate, db: Session = Depends(database.get_db), current_user: models.User = Depends(auth.get_current_user)):
    return crud.create_booking(db, booking, user_id=current_user.id)

@app.get("/api/bookings/my", response_model=List[schemas.BookingResponse])
def read_my_bookings(db: Session = Depends(database.get_db), current_user: models.User = Depends(auth.get_current_user)):
    return crud.get_user_bookings(db, user_id=current_user.id)

@app.get("/api/bookings/all", response_model=List[schemas.BookingResponse])
def read_all_bookings(db: Session = Depends(database.get_db), current_user: models.User = Depends(auth.require_admin)):
    return crud.get_all_bookings(db)

@app.put("/api/bookings/{booking_id}/status", response_model=schemas.BookingResponse)
def update_booking_status_route(booking_id: int, status_update: schemas.BookingStatusUpdate, db: Session = Depends(database.get_db)):
    updated = crud.update_booking_status(db, booking_id, status_update.booking_status)
    if not updated:
        raise HTTPException(status_code=404, detail="Booking not found")
    return updated

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
